from django.db import models
from django.utils import timezone
from .choices import TIPO_PROPRIETARIO, TIPO_TELEFONE, TIPO_USO, ESTADOS,SEXO,ESTADO_CIVIL,FORMA_PAGAMENTO, STATUS_PAGAMENTO, STATUS_CONTRATO,TIPO_CONTAMOIP, STATUS_FORMULARIO_COTACAO,STATUS_HABILITACAO, TIPO_PAGAMENTO, TIPO_PROPRIETARIO,RELACAO_PROPRIETARIO,TRANSFORMACAO_VEICULO,FINS_UTILIZACAO,ESTADOS,ADAPTACAO_PCD,ADAPTACAO_GNV,BLINDADO,CRV_ASSINADO,TRANSFERENCIA_DETRAN,QTD_NUMERO_ROUBOS,QUILOMETRAGEM_MENSAL,FINANCIADO, CONDUTOR_VEICULO, TIPO_CONDUTOR,COBERTURA_25_ANOS, GARAGEM_CASA, GARAGEM_ESTUDO, GARAGEM_TRABALHO, GRAU_PARENTESCO, CATEGORIA_VEICULO, VEICULO_NOVO, RENOVACAO, CLASSE_BONUS
from django.db.models.signals import post_save
from django.dispatch import receiver
from decimal import Decimal


class Cliente(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    email = models.CharField(max_length=100,blank=False, null=True)
    cpf = models.CharField(max_length=14,blank=False, null=True)
    rg = models.CharField(max_length=11,blank=False, null=True)
    tipo_cliente = models.IntegerField(default=1,blank=False, null=True)
    nome = models.CharField(max_length=250,blank=False, null=True)
    sexo = models.CharField(max_length=1,choices=SEXO,blank=False, null=True)
    data_nascimento = models.DateField(blank=False, null=True)
    estado_civil = models.CharField(max_length=1,choices=ESTADO_CIVIL,blank=False, null=True)
    nacionalidade = models.CharField(max_length=100,blank=False, null=True)
    ramo_atividade_id = models.IntegerField(blank=True, null=True)
    ocupacao_id = models.IntegerField(blank=False, null=True)
    senha = models.CharField(max_length=50,blank=False, null=True)

    def __str__(self):
        return '{0} - {1}'.format(self.nome, self.cpf)

    class Meta:
        verbose_name = 'Cliente'
        verbose_name_plural = 'Clientes'


class Endereco(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, null=True)
    cep = models.CharField(max_length=9, blank=False, null=True)
    rua = models.CharField(max_length=100,blank=False, null=True)
    numero = models.IntegerField(blank=False, null=True)
    complemento = models.CharField(max_length=20,blank=True, null=True)
    bairro = models.CharField(max_length=50,blank=False, null=True)
    cidade = models.CharField(max_length=50,blank=False, null=True)
    estado = models.CharField(max_length=2,choices=ESTADOS,blank=False, null=True)

    def __str__(self):
        return '{0}, {1}'.format(self.rua,(self.numero if self.numero else 'S/N'))

    class Meta:
        verbose_name = 'Endereço'
        verbose_name_plural = 'Endereços'

class Telefone(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    tipo_telefone = models.CharField(max_length=1,choices=TIPO_TELEFONE,blank=False, null=True)
    ddd_telefone = models.IntegerField(blank=False, null=True)
    telefone = models.CharField(max_length=10,blank=False, null=True)

    def __str__(self):
        return '({0}) {1}'.format(self.ddd_telefone, self.telefone)

    class Meta:
        verbose_name = 'Telefone'
        verbose_name_plural = 'Telefones'


class Veiculo(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    placa = models.CharField(max_length=8,blank=False, null=True)
    marca = models.CharField(max_length=250,blank=False, null=True)
    modelo = models.CharField(max_length=250,blank=False, null=True)
    ano = models.IntegerField(blank=False, null=True)
    ano_modelo = models.IntegerField(blank=False, null=True)
    fipe = models.CharField(max_length=10,blank=False, null=True)
    combustivel = models.IntegerField(blank=False, null=True)
    categoria_tarifaria = models.CharField(max_length=5,blank=False, null=True)
    chassi = models.CharField(max_length=18,blank=False, null=True)
    veiculo_novo = models.CharField(max_length=1,choices=VEICULO_NOVO,blank=False, null=True)
    categoria = models.CharField(max_length=1,choices=CATEGORIA_VEICULO,blank=False, null=True, default=0)
    renavam = models.CharField(max_length=11,blank=False, null=True)
    cor = models.CharField(max_length=20,blank=False, null=True)
    cidade_veiculo = models.CharField(max_length=50,blank=False, null=True)
    estado_veiculo = models.CharField(max_length=2,choices=ESTADOS,blank=False, null=True)
    transformacao_veiculo = models.CharField(max_length=1,choices=TRANSFORMACAO_VEICULO,blank=False, null=True)
    relacao_proprietario = models.CharField(max_length=1,choices=RELACAO_PROPRIETARIO,blank=False, null=True)
    fins_utilizacao = models.CharField(max_length=1,choices=FINS_UTILIZACAO,blank=False, null=True)
    adaptacao_pcd = models.CharField(max_length=1,choices=ADAPTACAO_PCD,blank=False, null=True)
    adaptacao_gnv = models.CharField(max_length=1,choices=ADAPTACAO_GNV,blank=False, null=True)
    transferencia_detran = models.CharField(max_length=1,choices=TRANSFERENCIA_DETRAN,blank=False, null=True)
    crv_assinado = models.CharField(max_length=1,choices=CRV_ASSINADO,blank=False, null=True)
    blindado =models.CharField(max_length=1,choices=BLINDADO,blank=False, null=True)
    numero_roubos = models.CharField(max_length=1,choices=QTD_NUMERO_ROUBOS,blank=False, null=True)
    financiado = models.CharField(max_length=1,choices=FINANCIADO,blank=False, null=True)
    data_compra = models.DateField(blank=False, null=True)

    def __str__(self):
        return '{0} - {1} - {2}/{3}'.format(self.placa, self.marca, self.ano, self.ano_modelo)

    class Meta:
        verbose_name = 'Veiculo'
        verbose_name_plural = 'Veiculos'


class Corretor(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    nome = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    ddd_telefone = models.IntegerField(verbose_name="DDD",blank=False, null=True)
    telefone = models.CharField(verbose_name="Telefone",max_length=11,null=True)
    cnpj = models.CharField(verbose_name="CNPJ",max_length=14,null=True)

    def __str__(self):
        return self.nome

    class Meta:
        verbose_name = 'Corretor'
        verbose_name_plural = 'Corretores'


class IndicacaoCorretor(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    nome = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    ddd_telefone = models.IntegerField(blank=False, null=True)
    telefone = models.CharField(max_length=9,blank=False, null=True)
    cnpj = models.CharField(max_length=14)
    data_indicacao = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=1, choices=STATUS_HABILITACAO)


    def __str__(self):
        return self.nome

    class Meta:
        verbose_name = 'Indicação de Corretor'
        verbose_name_plural = 'Indicações de Corretores'

class Cotacoes(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE)
    veiculo = models.ForeignKey(Veiculo, on_delete=models.CASCADE)
    cotacao_usebens_id = models.IntegerField(verbose_name="Código da Cotação",blank=False, null=True)
    cotacao_i4Pro_usebens_id = models.IntegerField(verbose_name="Código da Cotação i4Pro",blank=False, null=True)
    status_formulario = models.CharField(max_length=1,choices=STATUS_FORMULARIO_COTACAO,blank=False, null=False)
    data = models.DateTimeField(default=timezone.now)
    taxa_instalacao = models.DecimalField(max_digits=8, decimal_places=2, blank=False, null=True)
    parc_taxa_instalacao = models.IntegerField(verbose_name="Quantidade de Parcelas Taxa de Instalacao",blank=False, null=True)
    rastreamento = models.DecimalField(max_digits=8, decimal_places=2, blank=False, null=True)
    parc_rastreamento = models.IntegerField(verbose_name="Quantidade de Parcelas Taxa do Rastreamento",blank=False, null=True)
    valor_seguro = models.DecimalField(max_digits=8, decimal_places=2, blank=False, null=True, default=0)
    iof = models.DecimalField(max_digits=8, decimal_places=2, blank=False, null=True,default=0)
    produto = models.CharField(max_length=80, blank=False, null=True)

    class Meta:
        verbose_name = 'Cotação'
        verbose_name_plural = 'Cotações'

    def __str__(self):
        return '{0} - {1} - {2}/{3}'.format(self.veiculo.placa, self.veiculo.marca, self.veiculo.ano, self.veiculo.ano_modelo)

    def _get_valor_total_produto(self):
        if self.valor_seguro and self.iof:
            return round(Decimal(self.valor_seguro) + Decimal(self.iof) + Decimal(self.rastreamento) + Decimal(self.taxa_instalacao),2)
        return round(Decimal(self.rastreamento) + Decimal(self.taxa_instalacao),2)

    def _get_valor_seguro_rastreamento(self):
        return round(Decimal(self.valor_seguro) + Decimal(self.iof) + Decimal(self.rastreamento),2)

    valor_total = property(_get_valor_total_produto)
    valor_seguro_rastreamento = property(_get_valor_seguro_rastreamento)

class PreProposta(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    veiculo = models.ForeignKey(Veiculo,on_delete=models.CASCADE,null=True)
    cliente = models.ForeignKey(Cliente,on_delete=models.CASCADE,null=True)
    cotacao = models.ForeignKey(Cotacoes, on_delete=models.CASCADE,null=True)
    origem = models.CharField(max_length=20,default='',null=True, blank=True)
    data = models.DateField(default=timezone.now)
    codigo = models.CharField(verbose_name="Código da Proposta",max_length=8, default='',null=True, blank=True)
    empresa_id = models.IntegerField(null=True, blank=True)
    link = models.CharField(max_length=250,default='',null=True, blank=True)
    corretor = models.ForeignKey(Corretor,verbose_name="Corretor",null=True, blank=True, on_delete=models.SET_NULL)
    indicacao_corretor = models.ForeignKey(IndicacaoCorretor,verbose_name="Corretor indicado pelo Cliente",help_text='O Corretor indicado pelo Cliente precisa ser habilitado na página de Corretores.',null=True, blank=True, on_delete=models.SET_NULL)


    class Meta:
        verbose_name = 'Proposta'
        verbose_name_plural = 'Propostas'

    def __str__(self):
        return '{0}'.format(self.codigo) if self.codigo else '{0}'.format(self.id)


class Faturamento(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cotacao = models.ForeignKey(Cotacoes, null=True, on_delete=models.SET_NULL )
    proposta = models.ForeignKey(PreProposta,verbose_name="Proposta", null=True, on_delete=models.SET_NULL )
    usebens_invoice_id = models.IntegerField(verbose_name="Código Faturamento Usebens",blank=False, null=True)
    data = models.DateField(default=timezone.now)
    valor_total_servico = models.DecimalField(max_digits=8, decimal_places=2, blank=False, null=True)
    qtd_parcelas = models.IntegerField(verbose_name="Quantidade de Parcelas",blank=False, null=True)
    desconto = models.DecimalField(max_digits=8, decimal_places=2, blank=False, null=True)
    origem = models.CharField(max_length=20,default='',null=True, blank=True)

    class Meta:
        verbose_name = 'Faturamento'
        verbose_name_plural = 'Faturamentos'

    def __str__(self):
        return 'Faturamento - {0}'.format(self.usebens_invoice_id)


class RenovacaoSeguro(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cotacao = models.ForeignKey(Cotacoes, null=True, on_delete=models.SET_NULL )
    renovacao = models.CharField(max_length=1,choices=RENOVACAO,blank=False, null=True)
    classe_bonus = models.CharField(max_length=1,choices=CLASSE_BONUS,blank=False, null=True)
    numero_ci = models.CharField(max_length=256,blank=False, null=True)
    apolice_atual = models.CharField(max_length=50,blank=False, null=True)
    exp_apolice_atual = models.DateField(blank=False, null=True)
    cod_seguradora_atual = models.CharField(max_length=50,blank=False, null=True)


class CondutorVeiculo(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    veiculo = models.ForeignKey(Veiculo,null=True, on_delete=models.SET_NULL )
    cliente = models.ForeignKey(Cliente,null=True, on_delete=models.SET_NULL )
    cotacao = models.ForeignKey(Cotacoes, null=True, on_delete=models.SET_NULL )
    proposta = models.ForeignKey(PreProposta,verbose_name="Proposta", null=True, on_delete=models.SET_NULL )
    condutor_principal = models.CharField(max_length=1,choices=CONDUTOR_VEICULO,blank=False, null=True)
    nome = models.CharField(max_length=250,blank=False, null=True)
    cpf = models.CharField(max_length=14,blank=False, null=True)
    tipo = models.CharField(max_length=1,choices=TIPO_CONDUTOR,blank=False, null=True)
    sexo = models.CharField(max_length=1,choices=SEXO,blank=False, null=True)
    data_nascimento = models.DateField(blank=False, null=True)
    estado_civil = models.CharField(max_length=1,choices=ESTADO_CIVIL,blank=False, null=True)
    cobertura_25_anos = models.CharField(max_length=1,choices=COBERTURA_25_ANOS,blank=False, null=True)
    garagem_casa = models.CharField(max_length=2,choices=GARAGEM_CASA,blank=False, null=True)
    garagem_trabalho = models.CharField(max_length=2,choices=GARAGEM_TRABALHO,blank=False, null=True)
    garagem_estudo = models.CharField(max_length=2,choices=GARAGEM_ESTUDO,blank=False, null=True)
    quilometragem_mensal = models.CharField(max_length=1,choices=QUILOMETRAGEM_MENSAL,blank=False, null=True)

class ProprietarioVeiculo(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    veiculo = models.ForeignKey(Veiculo,null=True, on_delete=models.SET_NULL )
    cotacao = models.ForeignKey(Cotacoes, null=True, on_delete=models.SET_NULL )
    proposta = models.ForeignKey(PreProposta,verbose_name="Proposta", null=True, on_delete=models.SET_NULL )
    sexo = models.CharField(max_length=1,choices=SEXO,blank=False, null=True)
    data_nascimento = models.DateField(blank=False, null=True)
    nome = models.CharField(max_length=250,blank=False, null=True)
    cpf = models.CharField(max_length=14,blank=False, null=True)
    grau_parentesco = models.CharField(max_length=1,choices=GRAU_PARENTESCO,blank=False, null=True)


class PropostaUsebensFormalizada(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    id_usebens = models.IntegerField(verbose_name="Código da Proposta Formalizada",blank=False, null=True)
    origem = models.CharField(max_length=20,default='',null=True, blank=True)
    data = models.DateField(default=timezone.now)
    deferimento = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=20,default='Proposta não formalizada. Clique em "Formalizar Proposta" para submeter a UseBens.',null=True, blank=True)
    pe_fipe = models.CharField(max_length=10,default='',blank=True, null=True)
    aceitacao = models.CharField(max_length=50,default='',null=True, blank=True)
    proposta = models.ForeignKey(PreProposta,verbose_name="Proposta", null=True, on_delete=models.SET_NULL )
    companhia = models.IntegerField(null=True, blank=True)
    link = models.CharField(max_length=250,default='',null=True, blank=True)

    class Meta:
        verbose_name = 'Proposta Usebens Formalizada'
        verbose_name_plural = 'Propostas Usebens Formalizadas'

    def __str__(self):
        return '{0}'.format(self.origem)


class Contrato(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cliente_id = models.ForeignKey(Cliente,verbose_name="Cliente", null=True, on_delete=models.SET_NULL)
    veiculo_id = models.ForeignKey(Veiculo,verbose_name="Veiculo", null=True, on_delete=models.SET_NULL)
    clicksign_doc_key = models.CharField(verbose_name="Código ClickSign",max_length=250)
    url_contrato = models.CharField(verbose_name='URL Contrato',max_length=350)
    status_assinatura = models.IntegerField(verbose_name="Status de Assinatura",choices=STATUS_CONTRATO)
    termo_inicial = models.DateTimeField(verbose_name="Termo Inicial",default=timezone.now)
    termo_final= models.DateTimeField(verbose_name="Termo Final",auto_now=False,null=True, blank=True)
    proposta = models.ForeignKey(PreProposta,verbose_name="Proposta", null=True, on_delete=models.SET_NULL)

    class Meta:
        verbose_name = 'Contrato'
        verbose_name_plural = 'Contratos'

    def __str__(self):
        return '{0}'.format(self.id)


class AuthorizationAPI(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    key_api = models.TextField()
    secret_api = models.TextField()
    token = models.TextField()


class ServicosDoisMinutos(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    nome = models.CharField(max_length=50)
    descricao = models.CharField(max_length=250, blank=True, null=True)
    valor = models.DecimalField(verbose_name='Valor do Serviço (R$)',max_digits=6, decimal_places=2)
    qtd_parcelas = models.IntegerField(verbose_name='Quantidade máxima de parcelas',default=0)

    class Meta:
        verbose_name = 'Serviço 2 Minutos'
        verbose_name_plural = 'Serviços 2 Minutos'

    def __str__(self):
        return '{0}'.format(self.nome)


class PagamentoMoip(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    cliente_id = models.ForeignKey(Cliente,verbose_name="Cliente", on_delete=models.CASCADE)
    veiculo_id = models.ForeignKey(Veiculo,verbose_name="Veiculo", on_delete=models.CASCADE)
    descricao_produto =  models.CharField(verbose_name="Descrição do Produto", max_length=250)
    valor = models.DecimalField(verbose_name='Valor Total do Produto (R$)',max_digits=8, decimal_places=2)
    proposta = models.ForeignKey(PreProposta,verbose_name="Proposta", null=True, on_delete=models.SET_NULL)
    contrato = models.ForeignKey(Contrato,verbose_name="Contrato", null=True, on_delete=models.SET_NULL)

    class Meta:
        verbose_name = 'Pagamento Moip'
        verbose_name_plural = 'Pagamentos Moip'

    def __str__(self):
        return '{0}'.format(self.descricao_produto)

class ItemPagamentoMoip(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    pagamento_id = models.ForeignKey(PagamentoMoip,verbose_name="PagamentoMoip", null=True, on_delete=models.SET_NULL)
    valor_total = models.DecimalField(verbose_name='Valor Total do Item (R$)',max_digits=8, decimal_places=2)
    valor_parcela = models.DecimalField(verbose_name='Valor da Parcela (R$)',max_digits=8, decimal_places=2)
    qtd_parcelas = models.IntegerField(verbose_name='Quantidade de Parcelas',blank=False, null=True)
    tipo_pagamento = models.CharField(max_length=1,choices=TIPO_PAGAMENTO)
    descricao_item =  models.CharField(verbose_name="Descrição do Item", max_length=250,blank=True, null=True)
    data_primeira_parcela = models.DateField(blank=False, null=True)
    data_ultima_parcela = models.DateField(blank=False, null=True)
    codigo_plano = models.CharField(max_length=80, blank=True, null=True)
    codigo_assinatura_plano = models.CharField(max_length=80, blank=True, null=True)
    codigo_pagamento_moip = models.CharField(max_length=80, blank=True, null=True)
    codigo_cliente_moip = models.CharField(max_length=80, blank=True, null=True)
    nome_titular_cartao = models.CharField(max_length=250,blank=False, null=True)
    data_nascimento_titular = models.DateField(blank=False, null=True)
    cpf_titular = models.CharField(max_length=14,blank=False, null=True)
    ultimos_digitos_cartao = models.CharField(max_length=20,blank=False, null=True)
    atualizacao_status = models.DateTimeField(blank=False, null=True)

    def __str__(self):
        return self.descricao_item if self.descricao_item else self.pagamento_id.descricao_produto


class ContasMoip(models.Model):
    tipo = models.CharField(max_length=1,choices=TIPO_CONTAMOIP)
    pagador_taxa = models.BooleanField()
    contamoip_id = models.CharField(verbose_name= 'Conta Moip id',max_length=50)
    login = models.EmailField()
    nome_completo= models.CharField(max_length=250)
    percentual = models.IntegerField()

    class Meta:
        verbose_name = 'Conta Moip'
        verbose_name_plural = 'Contas Moip'

    def __str__(self):
        return '{0} - {1} - {2}'.format('Primária' if self.tipo == str(1) else 'Secundária', self.contamoip_id, self.login)


class ConfiguracoesAPIs(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)

    class Meta:
        verbose_name = 'Configuração de Api'
        verbose_name_plural = 'Configuracões de Api'

    def __str__(self):
        return '{0}'.format(self.id)


class ConfiguracoesAPIMoip(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    configuracoes = models.ForeignKey(ConfiguracoesAPIs, on_delete=models.CASCADE)
    token = models.CharField(max_length=300, help_text="Credencial fornecida pelo MOIP")
    key = models.CharField(max_length=300, help_text="Credencial fornecida pelo MOIP")
    contas =models.ManyToManyField(ContasMoip,verbose_name='Contas Moip (recebedores)')
    url_sucesso = models.CharField(max_length=300, verbose_name='Url de Sucesso',help_text="Página de redirecionamento: pagamento aprovado.")
    url_falha = models.CharField(max_length=300, verbose_name='Url de Falha', help_text="Página de redirecionamento: pagamento não processado.")
    assunto_email = models.CharField(max_length=100, verbose_name='Assunto do email de confirmação de pagamento',blank=True, null=True)
    corpo_email = models.TextField(verbose_name='Conteúdo do email',blank=True, null=True)

    class Meta:
        verbose_name = 'Configuracões Moip'
        verbose_name_plural = 'Configuracões Moip'

    def __str__(self):
        return '{0}'.format('Atenção! As alterações realizadas nessa seção podem alterar o funcionamento do sistema.')


class ConfiguracoesAPIClickSign(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    configuracoes = models.ForeignKey(ConfiguracoesAPIs, on_delete=models.CASCADE)
    access_token = models.CharField(max_length=300, help_text="Credencial gerada no ambiente ClickSign.")
    url_modelo_contrato = models.CharField(max_length=300,verbose_name='Diretorio do Modelo' ,help_text="Diretório do modelo de Contrato.")
    diretorio_clicksign =models.CharField(verbose_name='Diretorio ClickSign',help_text="Diretório no ambiente ClickSign para onde os contratos devem ser enviados.", max_length=100)
    prazo_contrato = models.IntegerField(verbose_name='Prazo', help_text="Quantidade de dias para término do prazo de assinatura")
    mensagem = models.CharField(help_text='Mensagem enviada no email padrão de assinatura (Máx. 300 caracteres)',max_length=300)
    assunto_email = models.CharField(max_length=100, verbose_name='Assunto do email após a assinatura do contrato',blank=True, null=True)
    corpo_email = models.TextField(verbose_name='Conteúdo do email',blank=True, null=True)

    class Meta:
        verbose_name = 'Configuracões ClickSign'
        verbose_name_plural = 'Configuracões ClickSign'

    def __str__(self):
        return '{0}'.format('Atenção! As alterações realizadas nessa seção podem alterar o funcionamento do sistema.')


class ConfiguracoesAPIUseBens(models.Model):
    id = models.AutoField(primary_key=True, blank=False, null=False)
    configuracoes = models.ForeignKey(ConfiguracoesAPIs, on_delete=models.CASCADE)
    key_api = models.CharField(max_length=300,verbose_name='Key API',help_text='Credencial fornecida pela UseBens.')
    secret_api = models.CharField(max_length=300,verbose_name='Secret API',help_text='Credencial fornecida pela UseBens.')
    token = models.CharField(max_length=300,help_text='Credencial (token) gerado pelo serviço UseBens através da Key e Secret.')

    class Meta:
        verbose_name = 'Configurações UseBens'
        verbose_name_plural = 'Configurações UseBens'

    def __str__(self):
        return '{0}'.format('Atenção! As alterações realizadas nessa seção podem alterar o funcionamento do sistema.')

$(function(){
  
  $('.tabs li').click(function(){
    var id = $(this).attr('id');
    $('.tabs li').removeClass('active');
    $(this).addClass('active');
    $('.painel-painel').removeClass('active-painel');
    $('.telemetria'+id).addClass('active-painel');
  });
  $(window.location.hash).click();
  
  $(window).scroll(function () { 
      if ($(this).scrollTop() > 200) { 
          $('.menuheader').addClass("fixedmenu"); 
      } else { 
          $('.menuheader').removeClass("fixedmenu"); 
      } 
  }); 
  
   $("input[name='telefone']").mask('(99) 99999-9999');
   $('#openmenu').click(function(){
      $('.menu-mobile').show();
   });
   $('button.close').click(function(){
      $('.menu-mobile').hide();
   });

   $('.formpadrao').submit(function(e){
      e.preventDefault();
      var regexEmail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

      var nome = $(this).find('input[name="nome"]');
      var email    = $(this).find("input[name='email']");
      var cpf    = $(this).find("input[name='cpf']");
      var telefone = $(this).find("input[name='telefone']");


      if(nome.val() == ""){
          nome.focus();
          return false;
      }

      if(email.val() == '') {
        email.focus();
        return false;
      }

      if(!regexEmail.test(email.val())){
        email.focus();
        alert('Email inválido!');
        return false;
      }

      if(cpf.val() == ''){
        cpf.focus();
        return false;
      }


      if(!CPF.validate(cpf.val())){
        alert('CPF inválido!');
        return false;
      }

      if(telefone.val() == '') {
        telefone.focus();
        return false;
      }
 
      if(telefone.val().length <= 13){
        telefone.focus();
        alert('Telefone inválido!')
        return false;
      }  
   })


   var $doc = $('html, body');
    $('a').click(function() {
        $doc.animate({
            scrollTop: $( $.attr(this, 'href') ).offset().top
        }, 500);
        clearTimeout(timer);
        clearTimeout(newTimer);
        $('.menumobile').css('right', '-660px');
        return false;
    });

});
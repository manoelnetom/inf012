var gulp = require('gulp');
var less = require('gulp-less');
var rename = require('gulp-rename');
var minifyCSS = require('gulp-csso');
var uglify = require('gulp-uglify');
var htmlmin = require('gulp-htmlmin');

gulp.task('html', function(){
  return gulp.src('default.html')
    .pipe(rename('index.html'))
    .pipe(htmlmin({collapseWhitespace: true}))
    .pipe(gulp.dest('.'))
});

gulp.task('css', function(){
  return gulp.src('css/custom.css')
    .pipe(less())
    .pipe(minifyCSS())
    .pipe(rename('style.min.css'))
    .pipe(gulp.dest('css/'))
});

gulp.task('js', function(){
  return gulp.src('js/custom.js')
    .pipe(uglify())
    .pipe(rename('script.min.js'))
    .pipe(gulp.dest('js/'))
});


gulp.task('default', [ 'html', 'css', 'js', 'img' ]);
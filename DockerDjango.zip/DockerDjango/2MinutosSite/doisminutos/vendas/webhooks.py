from .models import Cliente, Contrato, Endereco, Telefone ,ConfiguracoesAPIMoip, ItemPagamentoMoip,PagamentoMoip,PreProposta
from django.utils import timezone
from decimal import Decimal
import json
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from .views import gerar_contrato, assinar_digitalmente
from django.http import HttpResponseRedirect, HttpResponse
from .choices import ESTADOS, STATUS_PAGAMENTO, FORMA_PAGAMENTO
from django.conf import settings
import requests
from .usebens import usebens

#Este módulo possui as funções que recebem Webhooks dos serviços Moip e ClickSign

#### Recebimento de Pagamento - Moip ####
@require_POST
@csrf_exempt
def moip_webhook_pagamentos(request):
    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    print('web webhook pagamento recebido!  ', body)
    pagamento_instalacao = ItemPagamentoMoip.objects.filter(codigo_pagamento_moip = body.get('resource').get('payment').get('id'), descricao_item__iexact='Instalação').first()
    if pagamento_instalacao:
        pagamento_instalacao.atualizacao_status = body.get('resource').get('payment').get('updatedAt')
        pagamento_instalacao.save()
        if (body.get('event') == "PAYMENT.AUTHORIZED"):
            cliente=Cliente.objects.filter(id=pagamento_instalacao.pagamento_id.cliente_id.id).first()
            proposta = pagamento_instalacao.pagamento_id.proposta
            return gerar_novo_contrato(proposta,cliente, pagamento_instalacao.pagamento_id)
    return HttpResponse(status=302)

def gerar_novo_contrato(proposta,cliente, pagamento_id):
    try:
        url_contrato = gerar_contrato(proposta,cliente, pagamento_id)
        contrato = Contrato()
        contrato.proposta = pagamento_id.proposta
        contrato.cliente_id = cliente
        if url_contrato:
            contrato.url_contrato=url_contrato
            assinatura_digital = assinar_digitalmente(cliente, contrato.url_contrato)
            contrato.clicksign_doc_key = assinatura_digital.get('document').get('key')
            contrato.status_assinatura=1
            print('recebido webhook pagamento criado, status 1!')
            contrato.save()
            pagamento_contrato = pagamento_id
            pagamento_contrato.contrato = contrato
            pagamento_contrato.save()
            return HttpResponse(status=200)
    except ValueError:
        print ("Não foi possivel gerar o contrato! Aguardando novas tentativas")
    return HttpResponse(status=302)


def get_forma_pagamento(forma_pagamento):
    for fg in FORMA_PAGAMENTO:
        if fg[1] == forma_pagamento:
            return fg[0]


def get_status_pagamento(status_pagamento):
    for status in STATUS_PAGAMENTO:
        if status[1] == status_pagamento:
            return status[0]


####################Metodos para recebimento de Webhooks ClickSign#######################
####Documento assinado####
@require_POST
@csrf_exempt
def clicksign_webhook(request):
    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    print('web webhook contrato recebido!  ', body)

    if body.get('event').get('name') == "upload":
        contrato = Contrato.objects.all().filter(clicksign_doc_key=body.get('document').get('key')).first()
        if contrato and int(contrato.status_assinatura) == 1:
            contrato.status_assinatura = 2
            contrato.save()
            print('recebido webhook contrato upload ok, status 2!')

    if body.get('event').get('name') == "sign":
        contrato = Contrato.objects.all().filter(clicksign_doc_key=body.get('document').get('key')).first()
        if contrato and int(contrato.status_assinatura) < 3:
            url = body.get('document').get('downloads').get('signed_file_url')
            path = '{0}contrato_{1}_{2}.pdf'.format(settings.DIRETORIO_CONTRATOS, contrato.cliente_id.cpf, contrato.clicksign_doc_key)
            arquivo_baixado = False
            try:
                response = requests.get(url)
                with open(path, 'wb') as f:
                    f.write(response.content)
                    arquivo_baixado=True
                    print('baixou arquivo')
            except:
                arquivo_baixado=False
                print('ocorreu um erro ao baixar o arquivo')


            if arquivo_baixado:
                contrato.url_contrato=path
                contrato.status_assinatura=3
                contrato.concluido=body.get('event').get('occurred_at')
                contrato.save()
                # if contrato.proposta.codigo:
                #     result = usebens.formalizar_proposta(contrato.proposta.codigo)
                #     print('****Retorno usebens formalizar proposta:::',result)
                # print('recebido webhook contrato assinado ok, status 3!')
                return HttpResponse(status=200)
            return HttpResponse(status=500)
    return HttpResponse(status=200)


####################Metodos para recebimento de Webhooks UseBens#######################
####Pagamento Confirmado####
@require_POST
@csrf_exempt
def confirmacao_pagamento(request):
    body_unicode = request.body.decode('utf-8')
    body = json.loads(body_unicode)
    print('web webhook confirmacao_pagamento recebido!  ', body)

    if body.get('data'):
        if (body.get('data').get('status')=='AUTHORIZED') or (body.get('data').get('status')=='PRE_AUTHORIZED'):
            print('web webhook confirmacao_pagamento recebido - pre_proposal autorizada!  ', body)
            codigo_proposta = body.get('data').get('pre_proposal')
            if not codigo_proposta:
                return HttpResponse("Chave 'pre_proposal' não encontrada! verifique os parâmetros informados", status=404)

            pre_proposta = PreProposta.objects.filter(codigo = body.get('data').get('pre_proposal')).first()

            if not pre_proposta:
                return HttpResponse("código 'pre_proposal' não encontrado!", status=404)

            if PagamentoMoip.objects.filter(proposta = pre_proposta).first():
                pagamento = PagamentoMoip.objects.filter(proposta = pre_proposta).first()
            else:
                pagamento = PagamentoMoip()

            pagamento.cliente_id = pre_proposta.cliente
            pagamento.veiculo_id = pre_proposta.veiculo
            pagamento.descricao_produto = pre_proposta.cotacao.produto
            pagamento.valor = pre_proposta.cotacao.valor_total
            pagamento.proposta = pre_proposta
            pagamento.save()

            detalhes_pagamento_instalacao = ItemPagamentoMoip.objects.update_or_create(pagamento_id=pagamento, valor_total=pre_proposta.cotacao.taxa_instalacao,
                                                     valor_parcela=(pre_proposta.cotacao.taxa_instalacao / int(pre_proposta.cotacao.parc_taxa_instalacao)),
                                                     qtd_parcelas = int(pre_proposta.cotacao.parc_taxa_instalacao), tipo_pagamento = 1, #Cartão de Crédito
                                                     codigo_pagamento_moip = body.get('data').get('payment_id'), descricao_item="Instalação")
            detalhes_pagamento_seguro = ItemPagamentoMoip.objects.update_or_create(pagamento_id=pagamento, valor_total=pre_proposta.cotacao.valor_seguro_rastreamento,
                                                     valor_parcela=(pre_proposta.cotacao.valor_seguro_rastreamento / int(pre_proposta.cotacao.parc_rastreamento)),
                                                     qtd_parcelas = int(pre_proposta.cotacao.parc_rastreamento), tipo_pagamento = 1, #Cartão de Crédito
                                                     codigo_pagamento_moip = body.get('data').get('payment_id'), descricao_item="Rastreamento+Seguro")
            pagamento_instalacao = ItemPagamentoMoip.objects.filter(codigo_pagamento_moip = body.get('data').get('payment_id'), descricao_item__iexact='Instalação').first()
            contrato = gerar_novo_contrato(pre_proposta,pre_proposta.cliente, pagamento_instalacao.pagamento_id)
            print(contrato)
            return HttpResponse(status=200)
        else:
            print('web webhook confirmacao_pagamento recebido - pre_proposal ainda NÃO foi autorizada!  ', body)
            return HttpResponse(status=200)

    return HttpResponse("Chave 'data' não encontrada! verifique os parâmetros informados", status=404)

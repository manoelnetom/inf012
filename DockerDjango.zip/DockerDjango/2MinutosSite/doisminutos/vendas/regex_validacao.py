import re

cep_regex = re.compile(r'[0-9]{5}-[0-9]{3}', re.IGNORECASE)
cpf_regex = re.compile(r'[0-9]{11}')
placa_regex = re.compile(r'[A-Za-z0-9]*\d+[A-Za-z0-9]*$', re.IGNORECASE)
rg_regex = re.compile(r'[0-9]{10}')

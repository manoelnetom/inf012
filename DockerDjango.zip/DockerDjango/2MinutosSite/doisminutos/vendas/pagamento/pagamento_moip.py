import requests
import json
from ..models import  ContasMoip,ConfiguracoesAPIMoip, Cliente, Endereco, Telefone
from ..choices import TIPO_CONTAMOIP, ESTADOS
import string
import random
from django.conf import settings
from decimal import Decimal


class MoipAPI(object):

    def __init__(self):
        self.moip_api = ConfiguracoesAPIMoip.objects.all().first()
        self.token =  self.moip_api.token
        self.key = self.moip_api.key
        self.redirect_url=''


    def consultar_cliente(self, cliente_cpf):
        consultar_cliente_url = settings.MOIP_BASE_URL + '/v2/customers?q='
        response = requests.get('{0}{1}'.format(consultar_cliente_url, cliente_cpf), auth=(self.token, self.key),  verify=False)
        for costumer in response.json().get('customers'):
            if costumer.get('taxDocument')['number']==cliente_cpf:
                print('cliente existe:::::', costumer.get('id'))
                return costumer.get('id')
        return False


    def criar_cliente(self, cliente):
        consulta_cliente = self.consultar_cliente(cliente.cpf)
        endereco_cliente = Endereco.objects.filter(cliente__id=cliente.id).first()
        telefone_celular = Telefone.objects.filter(cliente__id=cliente.id).first()
        if not consulta_cliente:
            cliente_url = settings.MOIP_BASE_URL + '/v2/customers/'
            response = requests.post('{0}'.format(cliente_url),
                                     json = {"ownId": '{0}'.format(cliente.cpf),
                                             "fullname":'{0}'.format(cliente.nome),
                                             "email":'{0}'.format(cliente.email),
                                             "birthDate":'{0}'.format(cliente.data_nascimento),
                                             "taxDocument":{"type": "CPF","number":'{0}'.format(cliente.cpf)},
                                             "phone":{"countryCode": "55","areaCode":'{0}'.format(telefone_celular.ddd_telefone),"number":'{0}'.format(telefone_celular.telefone)},
                                             "shippingAddress":{"city": '{0}'.format(endereco_cliente.cidade),"district":'{0}'.format(endereco_cliente.bairro),
                                                                "street":'{0}'.format(endereco_cliente.rua),"streetNumber":'{0}'.format(endereco_cliente.numero),
                                                                "zipCode":'{0}'.format(endereco_cliente.cep),"state":'{0}'.format(self.get_estado_codigo(int(endereco_cliente.estado))),"country":"BRA" #verificar estados
                                                               }
                                                        }, auth=(self.token, self.key),  verify=False)

            if response.status_code==201:
                return response.json().get('id')
            return False

        return consulta_cliente


    def criar_pedido(self,costumer_moip, cliente, produto, preco):
        pagamento_url = settings.MOIP_BASE_URL + '/v2/orders/'
        identificador='{0}-{1}'.format(cliente.cpf, self.gerar_codigo_pedido())
        response = requests.post('{0}'.format(pagamento_url),
                                 json = {"ownId": identificador,
                                         "amount":{"currency":"BRL","subtotals":{"shipping":0}},
                                         "items":[{
                                                      "product": produto,
                                                      "category":"VEHICLES_AND_PARTS",
                                                      "quantity":1,
                                                      "detail":" ",
                                                      "price": preco
                                                   }],
                                         "customer":{"id": costumer_moip},
                                         "receivers": self.contas_split_pagamento(),
                                        "checkoutPreferences":{
                                                   "redirectUrls":{
                                                      "urlSuccess": "{0}".format(self.moip_api.url_sucesso),
                                                      "urlFailure": "{0}".format(self.moip_api.url_falha)
                                                   }
                                                   }},
                                 auth=(self.token, self.key),  verify=False)

        if response.status_code==201:
            return response.json().get('id')
        return False

    def format_data_nascimento(self,data_nascimento):
        data_split = data_nascimento.split('/')
        dia, mes, ano = data_split[0],data_split[1],data_split[2]
        return '{0}-{1}-{2}'.format(ano,mes,dia)

    def criar_pagamento(self,cliente,moip_pedido, qtd_parcelas,hash_cartao,nome_titular,nasc_titular,cpf_titular):
        pagamento_url = settings.MOIP_BASE_URL + '/v2/orders/{0}/payments'.format(moip_pedido)
        telefone_celular = Telefone.objects.filter(cliente__id=cliente.id).first()
        response = requests.post('{0}'.format(pagamento_url),
                                 json = {
                                          "installmentCount": qtd_parcelas,
                                          "statementDescriptor": "DoisMinutos",
                                          "fundingInstrument": {
                                            "method": "CREDIT_CARD",
                                            "creditCard": {
                                              "hash": '{0}'.format(hash_cartao),
                                              "store": False,
                                              "holder": {
                                                "fullname": '{0}'.format(nome_titular),
                                                "birthdate": '{0}'.format(nasc_titular),
                                                "taxDocument": {
                                                  "type": "CPF",
                                                  "number": '{0}'.format(cpf_titular)
                                                },
                                                "phone": {
                                                  "countryCode": "55",
                                                  "areaCode": '{0}'.format(telefone_celular.ddd_telefone),
                                                  "number": '{0}'.format(telefone_celular.telefone)
                                                }
                                              }
                                            }
                                          }
                                 },
                                 auth=(self.token, self.key),  verify=False)

        if response.status_code==201:
            return response.json().get('id')
        return False


    def gerar_codigo_pedido(self,size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for _ in range(size))

    def contas_split_pagamento(self):
        contas = self.moip_api.contas.all()
        lista=[]
        for conta in contas:
            lista.append({
                "type": self.get_tipo_conta(conta.tipo),
                "feePayor": conta.pagador_taxa,
                "moipAccount":{
                    "id": conta.contamoip_id,
                    "login": conta.login,
                    "fullname": conta.nome_completo
                },
                "amount":{
                    "percentual": 50
                }
            })
        return lista

    def get_tipo_conta(self, tipo_id):
        for tipo in TIPO_CONTAMOIP:
            if tipo[0] == tipo_id:
                return tipo[1]

    def get_estado_codigo(self, codigo_UF_usebens):
        estados_siglas =[('Acre','AC'),('Alagoas','AL'),('Amapá','AP'),('Amazonas','AM'),('Bahia','BA'),
                        ('Ceará','CE'),('Distrito Federal','DF'),('Espírito Santo','ES'),('Goiás','GO'),
                        ('Maranhão','MA'),('Mato Grosso','MT'),('Mato Grosso do Sul','MS'),('Minas Gerais','MG'),
                        ('Pará','PA'),('Paraíba','PB'),('Paraná','PR'),('Pernambuco','PE'),('Piauí','PI'),('Rio de Janeiro','RJ'),
                        ('Rio Grande do Norte','RN'),('Rio Grande do Sul','RS'),('Rondônia','RO'),('Roraima','RR'),('Santa Catarina','SC'),
                        ('São Paulo','SP'),('Sergipe','SE'),('Tocantins','TO'),]

        for estado in ESTADOS:
            if estado[0]==codigo_UF_usebens:
                for estado_sigla in estados_siglas:
                    if estado_sigla[0]==estado[1]:
                        return estado_sigla[1]
        return False

    def criar_plano(self, proposta, qtd_parcelas):
        plano_url = '{0}{1}'.format(settings.MOIP_BASE_URL, '/assinaturas/v1/plans')
        identificador=str('plano_{0}-{1}-{2}'.format(proposta.cliente.cpf,proposta.cotacao.produto, self.gerar_codigo_pedido())).replace(' ','').replace('+','_')
        response = requests.post('{0}'.format(plano_url),
                                 json = {
                                     "code": identificador,
                                     "name": str(proposta.cotacao.produto).replace('+','_'),
                                     "description": "DoisMinutos - Tecnologia e Rastreamento",
                                     "amount": '{0}'.format(str(round(Decimal(proposta.cotacao.valor_seguro_rastreamento / qtd_parcelas),2)).replace('.','')),
                                     # "setup_fee": 0, #A instalação terá que ser cobrada como credito rotativo comum.
                                     "max_qty": 1,
                                     "interval": {
                                       "length": 1,
                                       "unit": "MONTH"
                                     },
                                     "billing_cycles": qtd_parcelas, #quantidade de ciclos de fatura. Escolhido pelo cliente no formulário de pagamento
                                     "trial": {
                                       "days": 30, #cliente começará a ser cobrado após 30 dias da contratação
                                       "enabled": True#,
                                       # "hold_setup_fee": False
                                     },
                                     "payment_method": "CREDIT_CARD",
                                     "status": "ACTIVE"
                                 },
                                 auth=(self.token, self.key),  verify=False)

        if response.status_code==201:
            return identificador
        return False

    def criar_assinatura_com_assinante(self, proposta,codigo_plano):
        plano_url = '{0}{1}'.format(settings.MOIP_BASE_URL, '/assinaturas/v1/subscriptions?new_customer=true')
        identificador=str('assinatura_{0}-{1}-{2}'.format(proposta.cliente.cpf,proposta.cotacao.produto, self.gerar_codigo_pedido())).replace(' ','').replace('+','_')
        telefone_celular = Telefone.objects.filter(cliente__id=proposta.cliente.id).first()
        endereco_cliente = Endereco.objects.filter(cliente__id=proposta.cliente.id).first()
        response = requests.post('{0}'.format(plano_url),
                                 json = {
                                      "code": identificador,
                                      "payment_method": "CREDIT_CARD",
                                      "plan": {
                                          "name": str(proposta.cotacao.produto).replace('+','_'),
                                          "code": '{0}'.format(codigo_plano)
                                      },
                                      "customer": {
                                          "code": '{0}-{1}'.format(proposta.cliente.cpf, self.gerar_codigo_pedido()),
                                          "email": '{0}'.format(proposta.cliente.email),
                                          "fullname": '{0}'.format(proposta.cliente.nome),
                                          "cpf": '{0}'.format(proposta.cliente.cpf),
                                          "phone_number": '{0}'.format(telefone_celular.telefone),
                                          "phone_area_code": '{0}'.format(telefone_celular.ddd_telefone),
                                          "birthdate_day": '{0}'.format(proposta.cliente.data_nascimento.day),
                                          "birthdate_month": '{0}'.format(proposta.cliente.data_nascimento.month),
                                          "birthdate_year": '{0}'.format(proposta.cliente.data_nascimento.year),
                                          "address": {
                                              "street": '{0}'.format(endereco_cliente.rua),
                                              "number": '{0}'.format(endereco_cliente.numero),
                                              "complement": '{0}'.format(endereco_cliente.complemento) if endereco_cliente.complemento else " ",
                                              "district": '{0}'.format(endereco_cliente.bairro),
                                              "city": '{0}'.format(endereco_cliente.cidade),
                                              "state": '{0}'.format(self.get_estado_codigo(int(endereco_cliente.estado))),
                                              "country": "BRA",
                                              "zipcode": '{0}'.format(str(endereco_cliente.cep).replace('-',''))
                                          },
                                              "billing_info": {
                                                  "credit_card": {
                                                      "holder_name": "Nome Completo",
                                                      "number": "4111111111111111",
                                                      "expiration_month": "04",
                                                      "expiration_year": "25"
                                                  }
                                              }
                                      }
                                 },
                                 auth=(self.token, self.key),  verify=False)

        if response.status_code==201:
            return response.json()
        return False

from django.contrib import admin
from .models import Corretor, Cliente, Endereco, Veiculo, PreProposta, ServicosDoisMinutos, Telefone,Contrato, ContasMoip, ConfiguracoesAPIs, ConfiguracoesAPIUseBens, ConfiguracoesAPIMoip,ConfiguracoesAPIClickSign, Cotacoes, IndicacaoCorretor, PagamentoMoip, ItemPagamentoMoip, PropostaUsebensFormalizada, Faturamento
from .choices import STATUS_CONTRATO
from django.utils.html import format_html
from django.conf import settings
from django.http import HttpResponseRedirect
from django.contrib import messages
from .usebens import usebens

# Register your models here.

admin.site.site_header='2MIN Sistema Vendas'

class HiddenModelAdmin(admin.ModelAdmin):
    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}

#Moip
class ConfiguracoesApiMoipAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}

class ConfiguracoesAPIMoipInline(admin.StackedInline):
    model = ConfiguracoesAPIMoip
    extra = 0
    max_num=0
    list_display = ('token','key','contas','url_sucesso','url_falha')
    fields = [('token','key'),('url_sucesso','url_falha'),'contas','assunto_email', 'corpo_email']

    def has_delete_permission(self, request, obj=None):
        return False


#ClickSign
class ConfiguracoesAPIClickSignAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}

class ConfiguracoesAPIClickSignInline(admin.StackedInline):
    model = ConfiguracoesAPIClickSign
    extra = 0
    max_num=0
    list_display = ('access_token','url_modelo_contrato','diretorio_clicksign','prazo_contrato','mensagem')
    fields = ['access_token',('url_modelo_contrato','diretorio_clicksign'),('prazo_contrato','mensagem'),'assunto_email', 'corpo_email']

    def has_delete_permission(self, request, obj=None):
        return False

#UseBens
class ConfiguracoesAPIUseBensAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}

class ConfiguracoesAPIUseBensInline(admin.StackedInline):
    model = ConfiguracoesAPIUseBens
    extra = 0
    max_num=0
    list_display = ('key_api','secret_api','token')
    fields = [('key_api','secret_api'),'token']

    def has_delete_permission(self, request, obj=None):
        return False

#Configurações Gerais
class ConfiguracoesApisAdmin(admin.ModelAdmin):
    list_display = ('get_id',)
    actions = None
    inlines=[ConfiguracoesAPIUseBensInline,ConfiguracoesAPIMoipInline,ConfiguracoesAPIClickSignInline]
    fields=[]

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def get_id(self, obj):
        return 'Configurar Apis'
    get_id.short_description = 'Configurações'

#example
# class ClienteAdmin(admin.ModelAdmin):
#
#     def get_form(self, request, obj=None, **kwargs):
#         form = super(ClienteAdmin, self).get_form(request, obj, **kwargs)
#         veiculos=Cliente.objects.filter(cpf=obj.cpf).first().veiculos.all()
#         form.base_fields['veiculos'].queryset = veiculos #será refatorado
#         return form

#Demais Modelos
class VeiculoAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False

    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}


class EnderecoInline(admin.StackedInline):
    model = Endereco
    extra = 0
    max_num=0
    list_display = ('cep', 'rua', 'numero', 'complemento', 'bairro', 'cidade', 'estado')
    fields = ['cep', ('rua', 'numero', 'complemento'), 'bairro', ('cidade', 'estado')]


class TelefoneInline(admin.StackedInline):
    model = Telefone
    extra = 0
    max_num=0
    list_display = ('tipo_telefone', 'ddd_telefone', 'telefone')
    fields = ['tipo_telefone', ('ddd_telefone', 'telefone')]

class CotacaoAdmin(admin.ModelAdmin):
    list_display = ('produto', 'cliente', 'veiculo','status_formulario', 'data')
    search_fields = ['produto', 'cliente__cpf', 'cliente__nome', 'cliente__email', 'veiculo__placa', 'veiculo__marca', 'veiculo__modelo']
    actions_on_bottom = True
    actions_on_top = False

class CotacaoInline(admin.StackedInline):
    model = Cotacoes
    extra = 0
    max_num=0
    list_display = ('cliente', 'veiculo', 'status_formulario')
    fields = ['cliente', ('veiculo', 'status_formulario')]
    verbose_name = "Cotação"
    verbose_name_plural = "Cotações"


class ClienteAdmin(admin.ModelAdmin):
    list_display = ('cpf','nome', 'email', 'endereco','celular','telefone_fixo')
    fields = [('nome', 'email'), ( 'cpf', 'rg'), ('sexo','data_nascimento'),'estado_civil', 'senha']
    inlines = [EnderecoInline,TelefoneInline,CotacaoInline]
    search_fields = ['nome', 'cpf', 'email', 'rg','data_nascimento']
    actions_on_bottom = True
    actions_on_top = False

    def endereco(self, obj):
        endereco = Endereco.objects.filter(cliente__id=obj.id).first()
        return endereco

    def celular(self, obj):
        celular = Telefone.objects.filter(cliente__id=obj.id, tipo_telefone=2).first()
        return celular

    def telefone_fixo(self, obj):
        telefone_fixo = Telefone.objects.filter(cliente__id=obj.id, tipo_telefone=1).first()
        return telefone_fixo

class CorretorInline(admin.StackedInline):
    model = Corretor
    extra = 0
    max_num=0
    list_display = ('nome', 'email')
    fields = [('nome', 'email')]

class CorretorAdmin(admin.ModelAdmin):
    list_display = ('nome','email','get_telefone', 'cnpj')
    fields = ['nome','email',('ddd_telefone','telefone'), 'cnpj']
    search_fields = ['nome', 'email', 'cnpj']
    actions_on_bottom = True
    actions_on_top = False

    def get_telefone(self,obj):
        return '{0} {1}'.format(obj.ddd_telefone ,obj.telefone)
    get_telefone.short_description = 'Status'


class IndicacaoCorretorAdmin(admin.ModelAdmin):
    list_display = ('nome','email','get_telefone', 'cnpj')
    fields = ['nome','email',('ddd_telefone','telefone'), 'cnpj', 'status']
    search_fields = ['nome', 'email', 'cnpj']
    actions_on_bottom = True
    actions_on_top = False

    def get_telefone(self,obj):
        return '{0} {1}'.format(obj.ddd_telefone ,obj.telefone)
    get_telefone.short_description = 'Status'

    def has_add_permission(self, request):
        return False

class IndicacaoCorretorInline(admin.StackedInline):
    model = IndicacaoCorretor
    extra = 0
    max_num=0
    list_display = ('nome', 'email')
    fields = [('nome', 'email')]


class ContratoAdmin(admin.ModelAdmin):
    list_display = ('cliente_id','termo_inicial','get_status', 'get_url_contrato')
    fields = ['status_assinatura','cliente_id',('termo_inicial','termo_final'),('clicksign_doc_key', 'proposta')]
    search_fields = ['cliente_id__nome', 'cliente_id__cpf', 'clicksign_doc_key']
    actions_on_bottom = True
    actions_on_top = False

    def get_value_status(self,param):
        for status in STATUS_CONTRATO:
            if status[0]==param:
                return status[1]

    def get_status(self, obj):
        return self.get_value_status(obj.status_assinatura)
    get_status.short_description = 'Status'

    def get_url_contrato(self, obj):
        if int(obj.status_assinatura) != 3:
            return 'Visualização não disponivel'

        return format_html("<a href='{url}' target='_blank'>Visualizar Contrato</a>", url='/visualizar_contrato/{0}/'.format((obj.url_contrato).split('contrato_')[1]))
    get_url_contrato.short_description = "Url"


class ContratoInline(admin.StackedInline):
    model = Contrato
    extra = 0
    max_num=0
    list_display = '__all__'


class PropostaUsebensFormalizadaInline(admin.StackedInline):
    model = PropostaUsebensFormalizada
    extra = 1
    max_num=1
    fields = [('id_usebens','data', 'status'),('deferimento','pe_fipe', 'aceitacao'), ('companhia', 'link')]
    readonly_fields = ['id_usebens','data', 'status','deferimento','pe_fipe', 'aceitacao', 'companhia', 'link']
    list_display = '__all__'
    verbose_name = "Proposta Formalizada Usebens"



class PrePropostaAdmin(admin.ModelAdmin):
    list_display = ('cliente','veiculo','cotacao', 'data')
    readonly_fields = ['codigo', 'origem', 'empresa_id','link']
    search_fields = ['cliente_id__cpf','cliente_id__email','cliente_id__nome','veiculo__placa','veiculo__marca','veiculo__modelo','cotacao__cotacao_usebens_id']
    actions_on_bottom = True
    actions_on_top = False
    inlines=[PropostaUsebensFormalizadaInline]

    change_form_template = "formalizar-proposta.html"

    def response_change(self, request, obj):
        if "formalizar-proposta" in request.POST:
            formalizacao = usebens.formalizar_proposta(obj.codigo)
            print(formalizacao)
            if "error" in formalizacao:
                messages.add_message(request, messages.ERROR, 'Não foi possível formalizar a Proposta! Retorno UseBens: '+ formalizacao.get('error').get('message'))
            else:
                proposta_formalizada = PropostaUsebensFormalizada()
                proposta_formalizada.id_usebens = formalizacao.get('proposal').get('id')
                proposta_formalizada.origem = formalizacao.get('origin')
                proposta_formalizada.data = formalizacao.get('date')
                proposta_formalizada.proposta = obj
                proposta_formalizada.deferimento = formalizacao.get('proposal').get('endorsement')
                proposta_formalizada.status = formalizacao.get('proposal').get('status')
                proposta_formalizada.pe_fipe = formalizacao.get('proposal').get('pe_fipe')
                proposta_formalizada.aceitacao = formalizacao.get('proposal').get('acceptance')
                proposta_formalizada.empresa = formalizacao.get('company').get('id')
                proposta_formalizada.link = formalizacao.get('link')
                proposta_formalizada.save()
                messages.add_message(request, messages.INFO, 'Proposta formalizada com sucesso!')

            return HttpResponseRedirect(".")
        return super().response_change(request, obj)

    def get_form(self, request, obj=None, **kwargs):
        form = super(PrePropostaAdmin, self).get_form(request, obj, **kwargs)
        if obj:
            if obj.indicacao_corretor and obj.corretor is None:
                fieldsets = (
                    (None, {
                        'fields': ('codigo','cotacao','cliente','indicacao_corretor','data')
                    }),
                    ('Dados API UseBens', {
                        'fields': (('codigo','origem'),('empresa_id','link'))
                    }),
                )
                self.fieldsets=fieldsets

            if obj.corretor and obj.indicacao_corretor is None:
                fieldsets = (
                    (None, {
                        'fields': ('codigo','cotacao','cliente','corretor','data')
                    }),
                    ('Dados API UseBens', {
                        'fields': (('codigo','origem'),('empresa_id','link'))
                    }),
                )
                self.fieldsets=fieldsets

            if obj.corretor is None and obj.indicacao_corretor is None:
                fieldsets = (
                    (None, {
                        'fields': ('codigo','cotacao','cliente','corretor','data')
                    }),
                    ('Dados API UseBens', {
                        'fields': (('codigo','origem'),('empresa_id','link'))
                    }),
                )
                self.fieldsets=fieldsets

        form = super(PrePropostaAdmin, self).get_form(request, obj, **kwargs)
        cotacao = form.base_fields.get("cotacao", False)
        cotacao.widget.can_add_related = False
        cotacao.widget.can_delete_related = False
        cliente = form.base_fields.get("cliente", False)
        cliente.widget.can_add_related = False
        cliente.widget.can_delete_related = False
        corretor = form.base_fields.get("corretor", False)
        if corretor:
            corretor.widget.can_add_related = False
            corretor.widget.can_delete_related = False
            corretor.widget.can_change_related = False
        indicacao_corretor = form.base_fields.get("indicacao_corretor", False)
        if indicacao_corretor:
            indicacao_corretor.widget.can_add_related = False
            indicacao_corretor.widget.can_delete_related = False
            indicacao_corretor.widget.can_change_related = False
        return form


class ItemPagamentoMoipInline(admin.StackedInline):
    model = ItemPagamentoMoip
    extra = 0
    max_num=0
    list_display = ('valor_total',)
    fields = (('valor_total','tipo_pagamento'),('qtd_parcelas', 'valor_parcela'))
    verbose_name = "Pagamento"
    verbose_name_plural = "Datalhes do Pagamento e Assinatura de Planos"

    def has_delete_permission(self, request, obj=None):
        return False


class PagamentoMoipAdmin(admin.ModelAdmin):
    inlines=[ItemPagamentoMoipInline]
    list_display = ('cliente_id','veiculo_id','descricao_produto')
    search_fields = ['cliente_id__cpf', 'cliente_id__nome', 'cliente_id__email', 'descricao_produto', 'itempagamentomoip__nome_titular_cartao', 'itempagamentomoip__codigo_plano', 'itempagamentomoip__codigo_assinatura_plano']
    actions_on_bottom = True
    actions_on_top = False
    fieldsets = (
        (None, {
            'fields': ('cliente_id','veiculo_id', 'descricao_produto','valor')
        }),
    )

class FaturamentoAdmin(admin.ModelAdmin):
    list_display = ('usebens_invoice_id','data','cotacao','proposta','valor_total_servico')
    search_fields = ['usebens_invoice_id','cotacao__cliente__nome', 'cotacao__cliente__cpf','cotacao__cotacao_usebens_id','proposta__codigo']
    actions_on_bottom = True
    actions_on_top = False

    change_form_template = "consultar_pagamento.html"

    fieldsets = (
        (None, {
            'fields': ('cotacao','proposta')
        }),
        ('Dados API UseBens - Faturamento', {
            'fields': (('usebens_invoice_id', 'data', 'origem'),('valor_total_servico','desconto','qtd_parcelas'))
        }),
    )

    def has_add_permission(self, request):
        return False

    def response_change(self, request, obj):
        if "consultar-pagamento" in request.POST:
            try:
                consulta_parcela = usebens.consultar_pagamento(obj.usebens_invoice_id)
                print(consulta_parcela)
                if consulta_parcela:
                    if "error" in consulta_parcela:
                        messages.add_message(request, messages.ERROR, 'Ocorreu um erro na UseBens: {0}'.format(consulta_parcela.get('error').get('message')))
                    else:
                        pedido = consulta_parcela.get('result').get('invoice').get('installment').get('order').get('payment')
                        messages.add_message(request, messages.INFO, 'Detalhes do pagamento da 1º parcela: Código - {0} | Status - {1} | \
                                             Última Atualização: {2} '.format(pedido.get('id'), pedido.get('status'), consulta_parcela.get('result').get('invoice').get('installment').get('last_update')))
            except ValueError:
                messages.add_message(request, messages.ERROR, 'Não foi possível consultar o status da 1º parcela.')

            return HttpResponseRedirect(".")
        return super().response_change(request, obj)


admin.site.register(Corretor,CorretorAdmin)
admin.site.register(Cliente, ClienteAdmin)
admin.site.register(Endereco,HiddenModelAdmin)
admin.site.register(PreProposta, PrePropostaAdmin)
admin.site.register(ServicosDoisMinutos)
admin.site.register(PagamentoMoip,PagamentoMoipAdmin)
admin.site.register(Telefone,HiddenModelAdmin)
admin.site.register(Contrato,ContratoAdmin)
admin.site.register(ContasMoip,HiddenModelAdmin)
admin.site.register(ConfiguracoesAPIMoip,ConfiguracoesApiMoipAdmin)
admin.site.register(ConfiguracoesAPIClickSign,ConfiguracoesAPIClickSignAdmin)
admin.site.register(ConfiguracoesAPIUseBens,ConfiguracoesAPIUseBensAdmin)
admin.site.register(ConfiguracoesAPIs,ConfiguracoesApisAdmin)
admin.site.register(Veiculo, VeiculoAdmin)
admin.site.register(IndicacaoCorretor,IndicacaoCorretorAdmin)
admin.site.register(Cotacoes, CotacaoAdmin)
admin.site.register(Faturamento, FaturamentoAdmin)

from django.conf.urls import url
from . import views
from . import webhooks
from . import validacao_ajax
from .usebens import usebens

app_name = 'vendas'

urlpatterns = [
    #Páginas do Site
    url(r'^$', views.index, name='index'),
    url(r'^para-empresas.html$', views.para_empresas, name='para_empresas'),
    url(r'^para-voce.html$', views.para_voce, name='para_voce'),
    url(r'^franquia2minutos.html$', views.franquia2minutos, name='franquia2minutos'),
    url(r'^produtos-empresa.html$', views.produtos_empresa, name='produtos_empresa'),
    url(r'^acessesistema.html$', views.acessesistema, name='acessesistema'),
    #Views
    url(r'^consultar_veiculo$', views.consultar_veiculo.as_view(), name='consultar_veiculo'),
    url(r'^escolher_veiculo$', views.escolher_veiculo.as_view(), name='escolher_veiculo'),
    url(r'^consulta_profissao$', usebens.consulta_profissao, name='consulta_profissao'),
    url(r'^consulta_ramo_atividade$', usebens.consulta_ramo_atividade, name='consulta_ramo_atividade'),
    url(r'^preencher_formulario_rastreamento_seguro_cliente$', views.preencher_formulario_rastreamento_seguro_cliente.as_view(), name='preencher_formulario_rastreamento_seguro_cliente'),
    url(r'^preencher_formulario_rastreamento_seguro_veiculo$', views.preencher_formulario_rastreamento_seguro_veiculo.as_view(), name='preencher_formulario_rastreamento_seguro_veiculo'),
    url(r'^preencher_formulario_rastreamento_seguro_condutor$', views.preencher_formulario_rastreamento_seguro_condutor.as_view(), name='preencher_formulario_rastreamento_seguro_condutor'),

    url(r'^preencher_formulario_rastreamento$', views.preencher_formulario_rastreamento.as_view(), name='preencher_formulario_rastreamento'),
    url(r'^escolher_produto$', views.escolher_produto.as_view(), name='escolher_produto'),
    url(r'^confirmar_produto$', views.confirmar_produto.as_view(), name='confirmar_produto'),
    url(r'^escolher_corretor$', views.escolher_corretor.as_view(), name='escolher_corretor'),
    url(r'^renovacao_seguro$', views.renovacao_seguro.as_view(), name='renovacao_seguro'),
    url(r'^efetuar_pagamento$', views.efetuar_pagamento.as_view(), name='efetuar_pagamento'),
    url(r'^efetuar_pagamento_seguro$', views.efetuar_pagamento_seguro.as_view(), name='efetuar_pagamento_seguro'),
    url(r'^pagamento_sucesso$', views.pagamento_sucesso, name='pagamento_sucesso'),
    #Weebhooks
    url(r'^moip_webhook_pagamentos$', webhooks.moip_webhook_pagamentos, name='moip_webhook_pagamentos'),
    url(r'^clicksign_webhook$', webhooks.clicksign_webhook, name='clicksign_webhook'),
    url(r'^confirmacao_pagamento$', webhooks.confirmacao_pagamento, name='confirmacao_pagamento'),
    #Validação de campos
    url(r'^validar_cpf/$', validacao_ajax.validar_cpf, name='validar_cpf'),
    url(r'^validar_cep/$', validacao_ajax.validar_cep, name='validar_cep'),
    url(r'^validar_data_apolice/$', validacao_ajax.validar_data_apolice, name='validar_data_apolice'),
    url(r'^validar_data_nascimento/$', validacao_ajax.validar_data_nascimento, name='validar_data_nascimento'),
    url(r'^validar_data_nascimento/$', validacao_ajax.validar_data_nascimento, name='validar_data_nascimento'),
    url(r'^validar_data_validade_cartao/$', validacao_ajax.validar_data_validade_cartao, name='validar_data_validade_cartao'),
    #Utils
    url(r'^visualizar_contrato/(?P<param>[\w{}.-]{0,200})/$', views.visualizar_contrato, name='visualizar_contrato'),
    url(r'^enviar_email/$', views.enviar_email, name='enviar_email'),
    url(r'^processar_pagamento/$', views.processar_pagamento, name='processar_pagamento'),

]

import requests
import json
import string
import random
from ..models import Cliente, ConfiguracoesAPIClickSign
from django.conf import settings
import base64
import os.path
from django.utils import timezone


class ClickSign(object):

    def __init__(self, cliente, url_contrato):
        self.click_sign_api = ConfiguracoesAPIClickSign.objects.all().first()
        self.access_token = self.click_sign_api.access_token
        self.modelo_contrato = self.click_sign_api.url_modelo_contrato
        self.contrato = url_contrato
        self.cliente=cliente


    def criar_documento(self):
        url = '{0}{1}{2}'.format(settings.CLICKSIGN_BASE_URL, '/api/v1/documents?access_token=', self.access_token)
        response = requests.post(url, json = {"document": {
                                            "path": "{0}{1}".format(self.click_sign_api.diretorio_clicksign, str(self.contrato).split('contrato_')[1]),
                                            "deadline_at": self.get_prazo_assinatura(int(self.click_sign_api.prazo_contrato)),
                                            "auto_close": "true",
                                            "signers": [
                                              {
                                                "email": '{0}'.format(self.cliente.email),
                                                "sign_as": "sign",
                                                "auths": [
                                                  "email"
                                                ],
                                                "send_email": True,
                                                "message": "{0}".format(self.click_sign_api.mensagem)
                                              }
                                            ],
                                            "content_base64": '{0}{1}'.format('data:application/pdf;base64,',self.gerar_doc_base64(self.contrato))}
                                }, verify=False)
        print('ClickSign criar_documento',response.status_code)
        return response.json()


    def check_arquivo(self, path_contrato):
        return os.path.exists(path_contrato)


    def gerar_doc_base64(self, path_contrato):
        if self.check_arquivo(path_contrato):
            try:
                with open(path_contrato, "rb") as pdf_file:
                    encoded_string = base64.b64encode(pdf_file.read())
                    return encoded_string.decode('utf-8')
            except Exception as e:
                print(e.message, e.args)
        return False


    def get_prazo_assinatura(self, dias):
        now = timezone.now()
        prazo = now + timezone.timedelta(days=dias)
        prazo_utc = prazo.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]
        return '{0}{1}'.format(prazo_utc,'Z')

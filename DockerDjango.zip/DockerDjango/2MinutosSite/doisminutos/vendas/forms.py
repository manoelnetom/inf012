from django import forms
from .models import Cliente,PreProposta, Endereco, Veiculo, IndicacaoCorretor,CondutorVeiculo,RenovacaoSeguro
from .choices import FUEL_CHOICES, TIPO_PROPRIETARIO, ESTADO_CIVIL, ESTADOS, TIPO_PROPRIETARIO,RELACAO_PROPRIETARIO,TRANSFORMACAO_VEICULO,FINS_UTILIZACAO,ESTADOS,ADAPTACAO_PCD,ADAPTACAO_GNV,BLINDADO,CRV_ASSINADO,TRANSFERENCIA_DETRAN,QTD_NUMERO_ROUBOS,QUILOMETRAGEM_MENSAL,FINANCIADO, CONDUTOR_VEICULO, TIPO_CONDUTOR,COBERTURA_25_ANOS, GARAGEM_CASA, GARAGEM_ESTUDO, GARAGEM_TRABALHO, SEXO, CATEGORIA_VEICULO, VEICULO_NOVO
from django.core.exceptions import ValidationError
from django import forms
from django.core.exceptions import NON_FIELD_ERRORS
from django.core.validators import validate_email,RegexValidator
from .regex_validacao import cep_regex, cpf_regex, placa_regex, rg_regex


class ClienteForm(forms.ModelForm):
    placa = forms.CharField(max_length=8,validators=[RegexValidator(regex=placa_regex,message='Placa invalida',code='invalid')])
    email = forms.CharField()
    nome = forms.CharField(max_length=250)
    telefone_celular = forms.CharField(label='Telefone (Celular)',max_length=11)

    class Meta:
        model = Cliente
        fields = ['nome','email','telefone_celular','placa']




class CombustivelForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(CombustivelForm, self).__init__(*args, **kwargs)
        self.initial['combustivel'] = ''

    combustivel = forms.ChoiceField(choices=FUEL_CHOICES)

    class Meta:
        model = Veiculo
        fields = ['combustivel']


class EnderecoForm(forms.ModelForm):

    class Meta:
        model = Endereco
        fields = '__all__'


class FormularioRastreamento(forms.ModelForm):
    senha = forms.CharField(label='Senha',widget=forms.PasswordInput)
    confirmacao_senha = forms.CharField(label='Confirmar Senha',widget=forms.PasswordInput)
    ddd_telefone_fixo = forms.CharField(label='DDD (Fixo)',max_length=2)
    telefone_fixo = forms.CharField(label='Telefone (Fixo)',max_length=9)
    rg = forms.CharField(max_length=10)


    class Meta:
        model = Cliente
        fields = ['nome','cpf','rg', 'ddd_telefone_fixo','telefone_fixo','data_nascimento', 'senha', 'confirmacao_senha']


class FormularioRastreamentoSeguroCliente(forms.ModelForm):

    estado_civil = forms.ChoiceField(choices=ESTADO_CIVIL)
    senha = forms.CharField(widget=forms.PasswordInput)
    confirmacao_senha = forms.CharField(label='Confirmar Senha',widget=forms.PasswordInput)
    ddd_telefone_fixo = forms.CharField(label='DDD (Fixo)',max_length=2)
    telefone_fixo = forms.CharField(label='Telefone (Fixo)',max_length=9)
    cep = forms.CharField(max_length=9,validators=[RegexValidator(regex=cep_regex,message='CEP Invalido. Utilize o padrão xxxxx-xxx',code='invalid')])
    rua = forms.CharField(max_length=100)
    numero = forms.CharField(max_length=20)
    complemento = forms.CharField(max_length=20, required = False)
    bairro = forms.CharField(max_length=50)
    cidade = forms.CharField(max_length=50)
    estado = forms.CharField(max_length=50)

    class Meta:
        model = Cliente
        fields = ['nome','cpf','rg','email','data_nascimento','sexo','estado_civil','cep','rua', 'numero','complemento', 'bairro', 'cidade','estado', 'ddd_telefone_fixo','telefone_fixo', 'senha', 'confirmacao_senha']
        exclude = ['tipo_cliente', 'ramo_atividade_id']

class FormularioRastreamentoSeguroVeiculo(forms.ModelForm):

    veiculo_novo = forms.ChoiceField(choices=VEICULO_NOVO)
    categoria_veiculo = forms.ChoiceField(choices=CATEGORIA_VEICULO)
    relacao_proprietario = forms.ChoiceField(choices=RELACAO_PROPRIETARIO)
    transformacao_veiculo = forms.ChoiceField(choices=TRANSFORMACAO_VEICULO)
    fins_utilizacao = forms.ChoiceField(choices=FINS_UTILIZACAO)
    estado_veiculo = forms.ChoiceField(choices=ESTADOS)
    cidade_veiculo = forms.CharField(max_length=50)
    adaptacao_pcd = forms.ChoiceField(choices=ADAPTACAO_PCD)
    adaptacao_gnv = forms.ChoiceField(choices=ADAPTACAO_GNV)
    blindado = forms.ChoiceField(choices=BLINDADO)
    transferencia_detran = forms.ChoiceField(choices=TRANSFERENCIA_DETRAN)
    numero_roubos = forms.ChoiceField(choices=QTD_NUMERO_ROUBOS)
    financiado = forms.ChoiceField(choices=FINANCIADO)


    class Meta:
        model = Veiculo
        fields = ['adaptacao_gnv', 'categoria_veiculo', 'veiculo_novo','blindado','transferencia_detran','numero_roubos','financiado','relacao_proprietario','transformacao_veiculo','fins_utilizacao','estado_veiculo','cidade_veiculo','adaptacao_pcd']
        exclude = ['id', 'cliente', 'placa', 'marca', 'modelo', 'ano', 'ano_modelo', 'fipe', 'combustivel', 'categoria_tarifaria','chassi', 'tipo_uso', 'renavam', 'cor']


class FormularioRastreamentoSeguroCondutor(forms.ModelForm):

    condutor_principal = forms.ChoiceField(choices=CONDUTOR_VEICULO)
    tipo = forms.ChoiceField(choices=TIPO_CONDUTOR)
    sexo = forms.ChoiceField(choices=SEXO)
    estado_civil = forms.ChoiceField(choices=ESTADO_CIVIL)
    cobertura_25_anos = forms.ChoiceField(choices=COBERTURA_25_ANOS)
    garagem_casa = forms.ChoiceField(choices=GARAGEM_CASA)
    garagem_trabalho = forms.ChoiceField(choices=GARAGEM_TRABALHO)
    garagem_estudo = forms.ChoiceField(choices=GARAGEM_ESTUDO)
    quilometragem_mensal = forms.ChoiceField(choices=QUILOMETRAGEM_MENSAL)

    class Meta:
        model = CondutorVeiculo
        fields = ['veiculo','cpf', 'nome','cliente', 'cotacao', 'proposta', 'condutor_principal', 'tipo', 'sexo', 'data_nascimento', 'estado_civil', 'cobertura_25_anos', 'garagem_casa', 'garagem_trabalho', 'garagem_estudo', 'quilometragem_mensal']
        exclude = ['id', 'cliente', 'veiculo', 'cotacao', 'proposta']


class IndicacaoCorretorForm(forms.ModelForm):

    class Meta:
        model = IndicacaoCorretor
        fields = '__all__'
        exclude = ['data_indicacao', 'status','contrato']


class RenovacaoSeguroForm(forms.ModelForm):

    class Meta:
        model = RenovacaoSeguro
        fields = '__all__'
        exclude = ['cotacao', 'proposta', 'renovacao']

from django.shortcuts import render
from django.shortcuts import redirect
from sinesp_client import SinespClient
from .models import Cliente, Veiculo, Endereco, PreProposta, ServicosDoisMinutos, Telefone, Contrato, Cotacoes, Corretor, IndicacaoCorretor, PagamentoMoip, ItemPagamentoMoip,CondutorVeiculo, ProprietarioVeiculo,Faturamento, RenovacaoSeguro
from django.http import HttpResponseRedirect, HttpResponse,JsonResponse
from .forms import ClienteForm,EnderecoForm,FormularioRastreamento,FormularioRastreamentoSeguroCliente,IndicacaoCorretorForm,FormularioRastreamentoSeguroVeiculo,FormularioRastreamentoSeguroCondutor,RenovacaoSeguroForm
import requests
from requests.auth import HTTPBasicAuth
import json
import base64
from django.conf import settings
from copy import copy
import pycep_correios
from django.views import View
from .choices import ESTADOS, STATUS_PAGAMENTO, FORMA_PAGAMENTO, SEXO, ESTADO_CIVIL, TIPO_PROPRIETARIO, FUEL_CHOICES, RELACAO_PROPRIETARIO, GRAU_PARENTESCO, TRANSFORMACAO_VEICULO, FINS_UTILIZACAO,ADAPTACAO_PCD,ADAPTACAO_GNV,BLINDADO,CRV_ASSINADO,TRANSFERENCIA_DETRAN,QTD_NUMERO_ROUBOS, QUILOMETRAGEM_MENSAL,FINANCIADO, COR_VEICULO,CONDUTOR_VEICULO, TIPO_CONDUTOR,COBERTURA_25_ANOS, GARAGEM_CASA, GARAGEM_ESTUDO, GARAGEM_TRABALHO, CATEGORIA_VEICULO, VEICULO_NOVO, CLASSE_BONUS,SEGURADORAS
from datetime import datetime
from .pagamento.pagamento_moip import MoipAPI
from .gerar_contrato import gerador_pdf
from django.views.static import serve
import os
from .assinatura_digital.clicksign import ClickSign
import urllib
from django.utils import timezone
from decimal import Decimal
from .usebens import usebens
from django.db.models import Q
from django.http import FileResponse, Http404
from django.template.loader import render_to_string,get_template
from django.core.mail import EmailMessage
import re
from datetime import date

from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class consultar_veiculo(View):
    template_name = 'index.html'
    form_class = ClienteForm

    def get(self, request,*args, **kwargs):
        return HttpResponseRedirect('/')

    def post(self, request, *args, **kwargs):
        initial_data=dict(nome=request.POST['nome'], email=request.POST['email'],
                           placa=formatar_campo(request.POST['placa']),
                           ddd_telefone_celular=int(formatar_campo(request.POST['telefone'])[:2]),
                           telefone_celular=formatar_campo(request.POST['telefone'])[2:])
        form = ClienteForm(initial_data)
        if form.is_valid():
            post = form.save(commit=False)
            cliente= get_cliente_by_email(post.email)
            cliente.nome = post.nome
            cliente.email = post.email
            cliente.save()
            celular = get_telefone(cliente, 2)
            celular.ddd_telefone=int(formatar_campo(request.POST['telefone'])[:2])
            celular.telefone= formatar_campo(request.POST['telefone'])[2:]
            celular.save()

            # -- Comentado aguardando serviço de consulta de placa a ser fornecido pela 2minutos.--
            # Consulta a base do SINESP para obter informações do veiculo
            # consulta_sinesp_result = consulta_sinesp(request.POST['placa'])


            # if not consulta_sinesp_result:
            veiculo = Veiculo.objects.create(cliente=cliente, placa=request.POST['placa'])
            # else:
            #     veiculo = Veiculo.objects.create(cliente=cliente, placa=consulta_sinesp_result['placa'],marca=consulta_sinesp_result['marca'],
            #                                   ano=consulta_sinesp_result['ano'], ano_modelo=consulta_sinesp_result['anoModelo'])

            cotacao = Cotacoes.objects.create(cliente=cliente, veiculo=veiculo, status_formulario='1')
            cotacao.veiculo = veiculo
            cotacao.cliente = cliente
            cotacao.save()

            request.session['cotacao_id']= str(cotacao.id)
            return HttpResponseRedirect('escolher_veiculo')
        return render(request, 'erro.html',{'raise_error':'Formulário inicial possui dados inválidos!'})


class escolher_veiculo(View):
    template_name = 'escolher-veiculo.html'

    def get_endereco(self,cep):
        consulta_endereco = consultar_cep(cep)
        endereco = dict(cep=consulta_endereco['cep'],rua=consulta_endereco['end'],bairro=consulta_endereco['bairro'],cidade=consulta_endereco['cidade'],estado=consulta_endereco['uf'])
        return endereco

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        #Consulta os veiculos retornados pela UseBens com base no modelo informado (obtivo pelo SINESP)
        if not cotacao.veiculo.marca:
            return render(request, self.template_name, {'combustivel': FUEL_CHOICES ,'cor_veiculo': COR_VEICULO, 'placa':cotacao.veiculo.placa,'access_token': usebens.get_authorization().token,'url': '{0}/vehicles'.format(settings.BASE_URL)})
        else:
            marca_modelo_veiculo = usebens.verifica_marca_modelo_usebens(usebens.parser_sinesp_usebens(cotacao.veiculo.marca))
            if not marca_modelo_veiculo:
                return render(request, self.template_name, {'combustivel': FUEL_CHOICES,'cor_veiculo': COR_VEICULO,'placa': cotacao.veiculo.placa,'access_token': usebens.get_authorization().token,'url': '{0}/vehicles'.format(settings.BASE_URL)})

            initial_data = {'combustivel': FUEL_CHOICES,'cor_veiculo': COR_VEICULO, 'veiculo':marca_modelo_veiculo,'ano_veiculo':cotacao.veiculo.ano,
                           'ano_modelo_veiculo':cotacao.veiculo.ano_modelo,'placa':cotacao.veiculo.placa,'access_token': usebens.get_authorization().token,'url': '{0}/vehicles'.format(settings.BASE_URL)}
            return render(request, self.template_name, initial_data)
        return render(request, 'erro.html',{'raise_error':'Erro ao consultar veiculo usebens: '})

    def post(self, request, *args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        veiculo = cotacao.veiculo
        cliente = cotacao.cliente
        cliente.cpf = formatar_campo(request.POST['cpf'])
        cliente.save()
        veiculo_usebens = usebens.consulta_usebens_veiculos(request.POST['id_escolhido'])
        if veiculo_usebens:
            consulta_endereco = consultar_cep(request.POST['cep'])
            endereco = get_endereco_cliente(cliente)
            endereco.cep=request.POST['cep']
            endereco.rua=consulta_endereco['end']
            endereco.bairro=consulta_endereco['bairro']
            endereco.cidade=consulta_endereco['cidade']
            endereco.estado=get_codigo_UF(consulta_endereco['uf'])
            endereco.save()
            veiculo.marca = veiculo_usebens[0].get('vehicle')['make']
            veiculo.categoria_tarifaria=veiculo_usebens[0].get('vehicle').get('fare_category')
            veiculo.fipe=veiculo_usebens[0].get('vehicle').get('fipe')
            veiculo.modelo = veiculo_usebens[0].get('vehicle').get('model')
            veiculo.tipo_uso=1
            veiculo.cor = request.POST['cor_veiculo']
            veiculo.ano = request.POST['ano_veiculo']
            veiculo.ano_modelo = request.POST['ano_modelo']
            veiculo.combustivel = request.POST['combustivel']
            veiculo.save()
            cotacao.save()
            atualiza_status_formulario(cotacao.id,2)
            return HttpResponseRedirect('renovacao_seguro')
        return render(request, 'erro.html',{'raise_error':'Erro ao cotar seguro para veiculo na usebens: ' + veiculo_usebens})


class renovacao_seguro(View):
    template_name ='renovacao-seguro.html'
    form_class = RenovacaoSeguroForm

    def get_renovacao_seguro(self,cotacao):
        renovacao = RenovacaoSeguro.objects.filter(cotacao=cotacao).first()
        if renovacao:
            return renovacao
        else:
            return RenovacaoSeguro()



    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        initial_data = {'classe_bonus': CLASSE_BONUS, 'cod_seguradora_atual': TIPO_CONDUTOR,
                        'cod_seguradora_atual': SEGURADORAS}

        return render(request, self.template_name, {'initial_data':initial_data})

    def post(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        if 'renovar_seguro' in request.POST.keys():

            initial_data=dict(numero_ci=request.POST['numero_ci'], classe_bonus=request.POST['classe_bonus'],
                               apolice_atual= request.POST['apolice_atual'],
                               exp_apolice_atual= request.POST['exp_apolice_atual'],
                               cod_seguradora_atual= request.POST['cod_seguradora_atual'])

            form = RenovacaoSeguroForm(initial_data)
            if form.is_valid():
                renovacao_seguro = self.get_renovacao_seguro(cotacao)
                renovacao_seguro.cotacao = cotacao
                renovacao_seguro.renovacao = 1
                renovacao_seguro.numero_ci=form.cleaned_data['numero_ci']
                renovacao_seguro.classe_bonus=form.cleaned_data['classe_bonus']
                renovacao_seguro.apolice_atual= form.cleaned_data['apolice_atual']
                renovacao_seguro.exp_apolice_atual= form.cleaned_data['exp_apolice_atual']
                renovacao_seguro.cod_seguradora_atual= form.cleaned_data['cod_seguradora_atual']
                renovacao_seguro.save()
            else:
                return render(request, 'erro.html',{'raise_error':'O formulário de contratacao ou renovação de seguro do corretor possui dados inválidos'})
        return HttpResponseRedirect('escolher_produto')


class escolher_produto(View):

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        instalacao = ServicosDoisMinutos.objects.filter(nome__iexact='instalação').first()
        rastreamento = ServicosDoisMinutos.objects.filter(nome__iexact='rastreamento').first()

        return render(request, 'escolher-produto.html', {'rastreamento_valor': rastreamento.valor,
                                                         'rastreamento_parc': rastreamento.qtd_parcelas,'instalacao_valor':instalacao.valor,
                                                         'instalacao_parc':instalacao.qtd_parcelas,
                                                         'total_rastreamento_instalacao':round(rastreamento.valor+instalacao.valor,2),
                                                         'total_rastreamento_instalacao_seguro':' '})
    def post(self, request, *args, **kwargs):
        if request.POST['produto'] == "Rastreamento":
            return HttpResponseRedirect('preencher_formulario_rastreamento')
        if request.POST['produto'] == "Rastreamento+Seguro":
            return HttpResponseRedirect('preencher_formulario_rastreamento_seguro_cliente')
        else:
            return render(request, 'erro.html',{'raise_error':'Erro ao redirecionar para o formulário correspondente ao produto escolhido'})


class preencher_formulario_rastreamento(View):
    template_name_rastreamento = 'formulario-rastreamento.html'
    success_url = 'confirmacao_pagamento.html'
    erro_url = 'erro-formulario.html'
    form_class_rastreamento = FormularioRastreamento

    def get_sigla_codigo(self,codigo_uf):
        for estado in ESTADOS:
            if estado[0]==codigo_uf:
                return estado[1]

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        cliente = cotacao.cliente
        endereco = get_endereco_cliente(cliente)
        celular = get_telefone(cliente, 2)
        atualiza_status_formulario(cotacao.id,3)
        initial_data = {'nome':cliente.nome, 'cpf':cliente.cpf}
        form = self.form_class_rastreamento(initial = initial_data)
        return render(request, self.template_name_rastreamento, { 'form' : form,'nome_cliente':cliente.nome, 'cpf_cliente':cliente.cpf, 'celular_cliente': '({0}) {1}'.format(celular.ddd_telefone, celular.telefone), 'cep':endereco.cep,
                                                                 'rua': endereco.rua , 'bairro': endereco.bairro , 'cidade': endereco.cidade,'estado':self.get_sigla_codigo(str(endereco.estado)) })

    def post(self, request, *args, **kwargs):
        #Recupera informações da sessão
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        cliente = cotacao.cliente
        veiculo = cotacao.veiculo
        endereco = get_endereco_cliente(cliente)
        #Obtem informações do formulario JS
        initial_data=dict(nome=cliente.nome, cpf=cliente.cpf,
                          rg=formatar_campo(request.POST['rg']),
                          ddd_telefone_fixo=int(formatar_campo(request.POST['telefone_fixo'])[:2]),
                          telefone_fixo=formatar_campo(request.POST['telefone_fixo'])[2:],
                          data_nascimento= formatar_campo(request.POST['data_nascimento']),
                          senha= formatar_campo(request.POST['senha']),
                          confirmacao_senha= formatar_campo(request.POST['confirmar_senha']))
        form = FormularioRastreamento(initial_data)
        if form.is_valid():
            post = form.save(commit=False)
            instalacao = ServicosDoisMinutos.objects.filter(nome__iexact='instalação').first()
            rastreamento = ServicosDoisMinutos.objects.filter(nome__iexact='rastreamento').first()
            #Atualização de mais dados do cliente
            cliente.rg=post.rg
            cliente.senha=post.senha
            cliente.data_nascimento=post.data_nascimento
            endereco.numero = request.POST['numero']
            endereco.complemento = request.POST['complemento']
            endereco.save()
            #Criação registro telefone Fixo
            telefone_fixo = get_telefone(cliente, 1)
            telefone_fixo.ddd_telefone = int(formatar_campo(request.POST['telefone_fixo'])[:2])
            telefone_fixo.telefone = formatar_campo(request.POST['telefone_fixo'])[2:]
            telefone_fixo.save()
            cliente.save()

            instalacao = ServicosDoisMinutos.objects.filter(nome__iexact='instalação').first()
            rastreamento = ServicosDoisMinutos.objects.filter(nome__iexact='rastreamento').first()

            cotacao.produto = "Rastreamento"
            cotacao.valor_seguro = 0
            cotacao.iof = 0
            cotacao.rastreamento = rastreamento.valor
            cotacao.parc_rastreamento = rastreamento.qtd_parcelas
            cotacao.taxa_instalacao = instalacao.valor
            cotacao.parc_taxa_instalacao = instalacao.qtd_parcelas
            cotacao.save()
            pre_proposta= PreProposta()
            pre_proposta.cotacao = cotacao
            pre_proposta.veiculo=veiculo
            pre_proposta.cliente=cliente
            pre_proposta.save()
            request.session['pre_proposta_id']= str(pre_proposta.id)
            atualiza_status_formulario(cotacao.id,4)
            return HttpResponseRedirect('escolher_corretor')
        else:
            return render(request, 'erro.html',{'raise_error':'O formulário de Rastreamento possui dados inválidos'})


class preencher_formulario_rastreamento_seguro_cliente(View):
    template_name_rastreamento_seguro = 'formulario-rastreamento-seguro.html'
    success_url = 'confirmacao_pagamento.html'
    erro_url = 'erro-formulario.html'
    form_class_rastreamento_seguro = FormularioRastreamentoSeguroCliente

    def get_profissoes(self):
        lista_profissoes = usebens.consulta_profissao()
        profissoes = [('','Selecione a ocupação')]
        for profissao in lista_profissoes:
            profissoes.append((int(profissao['id']), profissao['occupation']))
        return profissoes

    def get_sigla_codigo(self,codigo_uf):
        for estado in ESTADOS:
            if estado[0]==codigo_uf:
                return estado[1]

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        cliente = cotacao.cliente
        endereco = get_endereco_cliente(cliente)
        celular = get_telefone(cliente, 2)
        atualiza_status_formulario(cotacao.id,3)
        profissoes = self.get_profissoes()
        initial_data = {'nome':cliente.nome, 'cpf':cliente.cpf,'email':cliente.email,
                        'cpf':cliente.cpf, 'cep':endereco.cep,'celular_cliente': celular,
                        'rua':endereco.rua, 'bairro': endereco.bairro,
                        'cidade':endereco.cidade,'estado':self.get_sigla_codigo(str(endereco.estado)),
                        'sexo': SEXO, 'estado_civil': ESTADO_CIVIL,
                        'profissoes':profissoes}
        return render(request, self.template_name_rastreamento_seguro, {'initial_data':initial_data})


    def post(self, request, *args, **kwargs):
        #Recupera informações da sessão
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        cliente = cotacao.cliente
        endereco = get_endereco_cliente(cliente)
        initial_data=dict(nome=cliente.nome, cpf=cliente.cpf,
                          rg=formatar_campo(request.POST['rg']),email=cliente.email,
                          data_nascimento= formatar_campo(request.POST['data_nascimento']),
                          sexo=int(request.POST['sexo']),estado_civil=int(request.POST['estado_civil']),
                          cep=endereco.cep,rua=endereco.rua,
                          numero=int(request.POST['numero']),complemento=request.POST['complemento'],
                          bairro=endereco.bairro,cidade=endereco.cidade,
                          estado=endereco.estado,ocupacao_id=int(request.POST['profissao']),
                          ddd_telefone_fixo=int(formatar_campo(request.POST['telefone_fixo'])[:2]),
                          telefone_fixo=formatar_campo(request.POST['telefone_fixo'])[2:],
                          ddd_telefone_comercial=int(formatar_campo(request.POST['telefone_comercial'])[:2]),
                          telefone_comercial=formatar_campo(request.POST['telefone_comercial'])[2:],
                          senha= formatar_campo(request.POST['senha']),
                          confirmacao_senha= formatar_campo(request.POST['confirmar_senha']))

        form = FormularioRastreamentoSeguroCliente(initial_data)
        if form.is_valid():
            # Atualização de dados de endereço do cliente
            endereco.numero=form.cleaned_data['numero']
            endereco.complemento=form.cleaned_data['complemento']
            endereco.estado=endereco.estado
            endereco.save()
            #Criação do registro de cliente
            cliente.rg=form.cleaned_data['rg']
            cliente.sexo=form.cleaned_data['sexo']
            cliente.data_nascimento=form.cleaned_data['data_nascimento']
            cliente.estado_civil=form.cleaned_data['estado_civil']
            cliente.nacionalidade = request.POST['nacionalidade']
            cliente.ocupacao_id=request.POST['profissao']
            cliente.senha=form.cleaned_data['senha']
            #Criação registro telefone Fixo
            telefone_fixo = get_telefone(cliente, 1)
            telefone_fixo.ddd_telefone = int(formatar_campo(request.POST['telefone_fixo'])[:2])
            telefone_fixo.telefone = formatar_campo(request.POST['telefone_fixo'])[2:]
            telefone_fixo.save()
            #Criação registro telefone Comercial
            telefone_comercial = get_telefone(cliente, 3)
            telefone_comercial.ddd_telefone = int(formatar_campo(request.POST['telefone_comercial'])[:2])
            telefone_comercial.telefone = formatar_campo(request.POST['telefone_comercial'])[2:]
            telefone_comercial.save()

            cliente.save()

            cotacao.produto = "Rastreamento+Seguro"
            cotacao.save()
            #Cria registro da Pre Proposta
            pre_proposta= PreProposta()
            pre_proposta.cotacao = cotacao
            pre_proposta.cliente=cliente
            pre_proposta.veiculo = cotacao.veiculo
            pre_proposta.save()
            request.session['pre_proposta_id']= str(pre_proposta.id)

            atualiza_status_formulario(cotacao.id,5) #Incluir novos status
            return HttpResponseRedirect('preencher_formulario_rastreamento_seguro_veiculo')
        else:
            return render(request, 'erro.html',{'raise_error':'O formulário de Rastreamento + Seguro possui dados inválidos'})


class preencher_formulario_rastreamento_seguro_veiculo(View):
    template_name_rastreamento_seguro = 'formulario-rastreamento-seguro-veiculo.html'
    success_url = 'confirmacao_pagamento.html'
    erro_url = 'erro-formulario.html'
    form_class_rastreamento_seguro = FormularioRastreamentoSeguroVeiculo

    def get_sigla_codigo(self,codigo_uf):
        for estado in ESTADOS:
            if estado[0]==codigo_uf:
                return estado[1]

    def format_data(self, date):
        data_split = date.split('/')
        dia, mes, ano = data_split[0],data_split[1],data_split[2]
        return '{0}-{1}-{2}'.format(ano,mes,dia)

    def get_proprietario(self, proposta):
        proprietario_existente =  ProprietarioVeiculo.objects.filter(proposta=proposta).first()
        if proprietario_existente:
            return proprietario_existente
        return ProprietarioVeiculo()

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        cliente = cotacao.cliente
        endereco = get_endereco_cliente(cliente)
        celular = get_telefone(cliente, 2)
        atualiza_status_formulario(cotacao.id,3)
        initial_data = {'veiculo_novo': VEICULO_NOVO,'relacao_proprietario': RELACAO_PROPRIETARIO,
                        'transformacao_veiculo':TRANSFORMACAO_VEICULO, 'categoria_veiculo': CATEGORIA_VEICULO,
                        'fins_utilizacao': FINS_UTILIZACAO,'estado_veiculo': ESTADOS,
                        'adaptacao_pcd': ADAPTACAO_PCD, 'adaptacao_gnv': ADAPTACAO_GNV, 'blindado': BLINDADO,
                        'crv_assinado': CRV_ASSINADO, 'transferencia_detran': TRANSFERENCIA_DETRAN, 'numero_roubos': QTD_NUMERO_ROUBOS,
                        'financiado': FINANCIADO,  'sexo': SEXO, 'grau_parentesco': GRAU_PARENTESCO}
        return render(request, self.template_name_rastreamento_seguro, {'initial_data':initial_data})


    def post(self, request, *args, **kwargs):
        #Recupera informações da sessão
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        veiculo = cotacao.veiculo
        initial_data=dict(veiculo_novo=request.POST['veiculo_novo'], relacao_proprietario=request.POST['relacao_proprietario'],
                          transformacao_veiculo=request.POST['transformacao_veiculo'],cidade_veiculo = request.POST['cidade_veiculo'],
                          fins_utilizacao=request.POST['fins_utilizacao'],estado_veiculo=request.POST['estado_veiculo'],
                          adaptacao_pcd=request.POST['adaptacao_pcd'],adaptacao_gnv=request.POST['adaptacao_gnv'],
                          blindado=request.POST['blindado'], categoria_veiculo= request.POST['categoria_veiculo'],
                          transferencia_detran=request.POST['transferencia_detran'],numero_roubos=request.POST['numero_roubos'],
                          financiado=request.POST['financiado'], grau_parentesco = request.POST['grau_parentesco'],
                          sexo = request.POST['sexo'], nome = request.POST['nome'], cpf = request.POST['cpf'], data_nascimento=request.POST['data_nascimento'])

        form = FormularioRastreamentoSeguroVeiculo(initial_data)

        if form.is_valid():
            #Atualização dados do Veiculo
            veiculo.chassi  = request.POST['chassi']
            veiculo.renavam = request.POST['renavam']
            veiculo.veiculo_novo  = form.cleaned_data['veiculo_novo']
            veiculo.categoria_veiculo = form.cleaned_data['categoria_veiculo']
            veiculo.relacao_proprietario = form.cleaned_data['relacao_proprietario']
            veiculo.transformacao_veiculo = form.cleaned_data['transformacao_veiculo']
            veiculo.fins_utilizacao = form.cleaned_data['fins_utilizacao']
            veiculo.cidade_veiculo = form.cleaned_data['cidade_veiculo']
            veiculo.estado_veiculo = self.get_sigla_codigo(str(form.cleaned_data['estado_veiculo']))
            veiculo.adaptacao_pcd =  form.cleaned_data['adaptacao_pcd']
            veiculo.adaptacao_gnv =  form.cleaned_data['adaptacao_gnv']
            veiculo.blindado =  form.cleaned_data['blindado']
            veiculo.transferencia_detran = form.cleaned_data['transferencia_detran']
            veiculo.numero_roubos = form.cleaned_data['numero_roubos']
            veiculo.financiado = form.cleaned_data['financiado']
            veiculo.save()

            #Recuperar preproposta
            pre_proposta = PreProposta.objects.filter(id=request.session.get('pre_proposta_id')).first()
            pre_proposta.veiculo=veiculo
            pre_proposta.save()

            #Registro de dados do proprietário do veiculo (caso nao seja o segurado)
            if request.POST['relacao_proprietario'] and request.POST['relacao_proprietario'] != '1':
                proprietario = self.get_proprietario(pre_proposta)
                proprietario.cotacao = pre_proposta.cotacao
                proprietario.proposta = pre_proposta
                proprietario.veiculo = veiculo
                proprietario.nome = request.POST['nome']
                proprietario.cpf = request.POST['cpf']
                proprietario.data_nascimento = self.format_data(request.POST['data_nascimento'])
                proprietario.sexo = request.POST['sexo']
                proprietario.grau_parentesco = request.POST['grau_parentesco']
                proprietario.save()

                if request.POST['relacao_proprietario'] != '3':
                    veiculo.crv_assinado =  request.POST['crv_assinado']
                    veiculo.data_compra =self.format_data(request.POST['data_compra'])
                    veiculo.save()

            atualiza_status_formulario(cotacao.id,5)
            return HttpResponseRedirect('preencher_formulario_rastreamento_seguro_condutor')
        else:
            return render(request, 'erro.html',{'raise_error':'O formulário de Rastreamento + Seguro possui dados inválidos'})


class preencher_formulario_rastreamento_seguro_condutor(View):
    template_name_rastreamento_seguro = 'formulario-rastreamento-seguro-condutor.html'
    success_url = 'confirmacao_pagamento.html'
    erro_url = 'erro-formulario.html'
    form_class_rastreamento_seguro = FormularioRastreamentoSeguroCondutor

    def get_sigla_codigo(self,codigo_uf):
        for estado in ESTADOS:
            if estado[0]==codigo_uf:
                return estado[1]
    def get_condutor(self, proposta):
        condutor_existente =  CondutorVeiculo.objects.filter(proposta=proposta).first()
        if condutor_existente:
            return condutor_existente
        return CondutorVeiculo()

    def format_data(self, date):
        print(date)
        data_split = date.split('-')
        dia, mes, ano = data_split[0],data_split[1],data_split[2]
        return '{0}-{1}-{2}'.format(ano,mes,dia)

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        atualiza_status_formulario(cotacao.id,3)
        initial_data = {'condutor_principal': CONDUTOR_VEICULO, 'tipo_condutor': TIPO_CONDUTOR,
                        'sexo': SEXO, 'estado_civil': ESTADO_CIVIL,
                        'cobertura_25_anos': COBERTURA_25_ANOS, 'quilometragem_mensal': QUILOMETRAGEM_MENSAL,
                        'garagem_casa': GARAGEM_CASA, 'garagem_trabalho': GARAGEM_TRABALHO,
                        'garagem_estudo': GARAGEM_ESTUDO}
        return render(request, self.template_name_rastreamento_seguro, {'initial_data':initial_data})


    def post(self, request, *args, **kwargs):
        #Recupera informações da sessão
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        initial_data = {'condutor_principal': request.POST['condutor_principal'], 'tipo': request.POST['tipo_condutor'],'nome': request.POST['nome'],
                        'sexo': request.POST['sexo'], 'estado_civil': request.POST['estado_civil'], 'data_nascimento': request.POST['data_nascimento'],
                        'cobertura_25_anos': request.POST['cobertura_25_anos'], 'quilometragem_mensal': request.POST['quilometragem_mensal'],
                        'garagem_casa': request.POST['garagem_casa'], 'garagem_trabalho': request.POST['garagem_trabalho'],
                        'garagem_estudo': request.POST['garagem_estudo'], 'cpf': request.POST['cpf']}

        #Recuperar preproposta
        pre_proposta = PreProposta.objects.filter(id=request.session.get('pre_proposta_id')).first()

        condutor = self.get_condutor(pre_proposta)
        condutor.cliente = pre_proposta.cliente
        condutor.veiculo =  pre_proposta.veiculo
        condutor.cotacao =  pre_proposta.cotacao
        condutor.proposta = pre_proposta
        condutor.condutor_principal = request.POST['condutor_principal']
        condutor.tipo = request.POST['tipo_condutor']
        condutor.save()
        if request.POST['tipo_condutor'] in ('1','2'):
            if request.POST['condutor_principal'] == '1':
                initial_data.update(nome = cotacao.cliente.nome)
                initial_data.update(cpf = cotacao.cliente.cpf)
                initial_data.update(data_nascimento = cotacao.cliente.data_nascimento)
                initial_data.update(estado_civil = cotacao.cliente.estado_civil)
                initial_data.update(sexo = cotacao.cliente.sexo)
            form = FormularioRastreamentoSeguroCondutor(initial_data)

            if form.is_valid():
                condutor.tipo = form.cleaned_data['tipo']
                condutor.condutor_principal = form.cleaned_data['condutor_principal']
                condutor.cobertura_25_anos = form.cleaned_data['cobertura_25_anos']
                condutor.quilometragem_mensal = form.cleaned_data['quilometragem_mensal']
                condutor.garagem_casa = form.cleaned_data['garagem_casa']
                condutor.garagem_trabalho = form.cleaned_data['garagem_trabalho']
                condutor.garagem_estudo = form.cleaned_data['garagem_estudo']
                condutor.save()

                if form.cleaned_data['condutor_principal'] == '0':
                    condutor.cpf = form.cleaned_data['cpf']
                    condutor.nome = form.cleaned_data['nome']
                    condutor.sexo = form.cleaned_data['sexo']
                    condutor.estado_civil = form.cleaned_data['estado_civil']
                    condutor.data_nascimento = form.cleaned_data['data_nascimento']
                    condutor.save()

                cotacao.produto = "Rastreamento+Seguro"
                cotacao.save()
                atualiza_status_formulario(cotacao.id,5)
            else:
                return render(request, 'erro.html',{'raise_error':'O formulário de Rastreamento + Seguro possui dados inválidos'})
        return HttpResponseRedirect('confirmar_produto')

class confirmar_produto(View):

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')

        usebens_cotacao = usebens.efetuar_cotacao(cotacao.cliente, cotacao.veiculo, cotacao)

        instalacao = ServicosDoisMinutos.objects.filter(nome__iexact='instalação').first()
        rastreamento = ServicosDoisMinutos.objects.filter(nome__iexact='rastreamento').first()

        if not usebens_cotacao or 'error' in usebens_cotacao:
            return render(request, 'erro.html',{'raise_error':'Erro ao confirmar escolha do produto'})

        cotacao.cotacao_usebens_id = usebens_cotacao.get('result').get('quote')['id']
        cotacao.cotacao_i4Pro_usebens_id = usebens_cotacao.get('result').get('quote')['i4pro_code']
        cotacao.taxa_instalacao = instalacao.valor
        cotacao.parc_taxa_instalacao = instalacao.qtd_parcelas
        cotacao.rastreamento = rastreamento.valor
        cotacao.parc_rastreamento =rastreamento.qtd_parcelas
        cotacao.valor_seguro = Decimal(usebens_cotacao.get('result').get('quote')['vl_premium_rate'])
        cotacao.iof = Decimal(usebens_cotacao.get('result').get('quote')['vl_iof'])
        cotacao.save()

        valor_seguro =round(Decimal(cotacao.valor_seguro) + Decimal(cotacao.iof),2)
        valor_rastreamento_e_seguro = (valor_seguro+cotacao.rastreamento)
        return render(request, 'confirmar-produto.html', {'valor_rastreamento_e_seguro':valor_rastreamento_e_seguro,'valor_seguro': valor_seguro,'rastreamento_valor': cotacao.rastreamento,
                                                         'rastreamento_parc': rastreamento.qtd_parcelas,'instalacao_valor':cotacao.taxa_instalacao,
                                                         'instalacao_parc':instalacao.qtd_parcelas,
                                                         'total_rastreamento_instalacao':round(cotacao.rastreamento+cotacao.taxa_instalacao,2),
                                                         'total_rastreamento_instalacao_seguro':round(Decimal(cotacao.rastreamento)+Decimal(cotacao.taxa_instalacao)+valor_seguro, 2)})

    def post(self, request, *args, **kwargs):
        pre_proposta = PreProposta.objects.filter(id=request.session.get('pre_proposta_id')).first()
        if efetuar_proposta(pre_proposta):
            return HttpResponseRedirect('escolher_corretor')
        return render(request, 'erro.html',{'raise_error':'Erro ao confirmar escolha do produto'})


def efetuar_proposta(pre_proposta):
    proprietario = ProprietarioVeiculo.objects.filter(proposta = pre_proposta).first()
    condutor = CondutorVeiculo.objects.filter(proposta = pre_proposta).first()
    #Criar uma Pre-Proposta na UseBens
    result_preproposta_usebens = usebens.pre_proposta_usebens(pre_proposta, pre_proposta.cliente,pre_proposta.veiculo, condutor, proprietario)
    if 'error' in result_preproposta_usebens:
        return render(request, 'erro.html',{'raise_error':'Erro ao efetuar Pre Proposta na UseBens: ' + result_preproposta_usebens.get('error').get('message')})

    pre_proposta.origem = result_preproposta_usebens.get('result')['origin']
    pre_proposta.data = datetime.strptime(result_preproposta_usebens.get('result')['date'], '%Y-%m-%d %H:%M:%S')
    pre_proposta.codigo = result_preproposta_usebens.get('result')['pre_proposal']['code']
    pre_proposta.empresa_id = result_preproposta_usebens.get('result').get('company')['id']
    pre_proposta.link = result_preproposta_usebens.get('result')['link']
    pre_proposta.save()
    return True

class escolher_corretor(View):
    template_name ='escolher-corretor.html'
    form_class = IndicacaoCorretorForm

    def get(self, request,*args, **kwargs):
        cotacao = Cotacoes.objects.filter(id=request.session.get('cotacao_id')).first()
        if not cotacao:
            return HttpResponseRedirect('/')
        return render(request, self.template_name, {})

    def post(self, request,*args, **kwargs):
        pre_proposta = PreProposta.objects.filter(id = request.session.get('pre_proposta_id')).first()
        if not pre_proposta:
            return HttpResponseRedirect('/')
        if 'indicar_corretor' in request.POST.keys():
            initial_data=dict(nome=request.POST['nome'], email=request.POST['email'],
                               cnpj=(formatar_campo(request.POST['cnpj'])).replace('/',''),
                               ddd_telefone=int(formatar_campo(request.POST['telefone'])[:2]),
                               telefone=formatar_campo(request.POST['telefone'])[2:])

            form = self.form_class(initial_data)
            if form.is_valid():
                post = form.save(commit=False)
                indicacao_corretor = IndicacaoCorretor(nome=post.nome, email=post.email,ddd_telefone=int(formatar_campo(request.POST['telefone'])[:2]),telefone=formatar_campo(request.POST['telefone'])[2:],cnpj=post.cnpj,status=2)
                indicacao_corretor.save()
                pre_proposta.indicacao_corretor=indicacao_corretor
                pre_proposta.save()
            else:
                return render(request, 'erro.html',{'raise_error':'O formulário de indicação do corretor possui dados inválidos'})

        if pre_proposta.cotacao.produto == "Rastreamento":
            return HttpResponseRedirect('efetuar_pagamento')
        elif pre_proposta.cotacao.produto == "Rastreamento+Seguro":
            return HttpResponseRedirect('efetuar_pagamento_seguro')


class efetuar_pagamento_seguro(View):
    template_name ='efetuar_pagamento_seguro.html'

    def get_valores_parcelas(self,qtd_max_parcelas,valor):
        result=[('','Selecione uma parcela'),]
        for index in range(1, qtd_max_parcelas):
            result.append((index, '{0}x R$ {1}'.format(str(index),round(Decimal(valor/index),2))))
        return result

    def parcelas_instalacao(self,cotacao):
        return self.get_valores_parcelas(cotacao.parc_taxa_instalacao+1,cotacao.taxa_instalacao)

    def parcelas_seguro(self, cotacao):
        if cotacao.produto == "Rastreamento":
            return self.get_valores_parcelas(cotacao.parc_rastreamento+1,cotacao.rastreamento)
        elif cotacao.produto == "Rastreamento+Seguro":
            valor_seguro = round(Decimal(cotacao.valor_seguro) + Decimal(cotacao.iof) + Decimal(cotacao.rastreamento),2)
            print(self.get_valores_parcelas(cotacao.parc_rastreamento+1,valor_seguro))
            #Rastreamento mais seguro sempre em 12 vezes)
            result=[('','Selecione uma parcela'),]
            result.append((1, '{0}x R$ {1}'.format(str(12),round(Decimal(valor_seguro/12),2))))
            #print(result)
            return result
            #return self.get_valores_parcelas(cotacao.parc_rastreamento+1,valor_seguro)

    def get(self, request,*args, **kwargs):
        proposta = PreProposta.objects.filter(id = request.session.get('pre_proposta_id')).first()
        if not proposta:
            return HttpResponseRedirect('/')
        #print(self.parcelas_seguro(proposta.cotacao))
        initial_data = {'parcelas_instalacao':self.parcelas_instalacao(proposta.cotacao),
                        'parcelas_seguro':self.parcelas_seguro(proposta.cotacao),
                        'produto': proposta.cotacao.produto}

        return render(request, self.template_name, {'initial_data':initial_data})


    def post(self, request,*args, **kwargs):
        proposta = PreProposta.objects.filter(id = request.session.get('pre_proposta_id')).first()
        if not proposta:
            return HttpResponseRedirect('/')

        cotacao = proposta.cotacao
        cotacao.parc_taxa_instalacao = request.POST['taxa_instalacao']
        #cotacao.parc_rastreamento = request.POST['valor_seguro']
        cotacao.parc_rastreamento = 12
        print("Aqui Parcelas QDA")
        print(cotacao.parc_rastreamento)
        print(cotacao.parc_taxa_instalacao)
        cotacao.save()
        criar_faturamento = usebens.criar_faturamento(cotacao)
        if criar_faturamento:
            faturamento = Faturamento()
            faturamento.cotacao = proposta.cotacao
            faturamento.proposta = proposta
            faturamento.usebens_invoice_id = criar_faturamento.get('result').get('invoice')['id']
            faturamento.valor_total_servico = criar_faturamento.get('result').get('invoice')['service_total']
            faturamento.qtd_parcelas = criar_faturamento.get('result').get('invoice')['number_installments']
            faturamento.desconto = criar_faturamento.get('result').get('invoice')['discount']
            faturamento.origem = criar_faturamento.get('result').get('origin')
            faturamento.save()

            usebens.notificacao_pagamento(proposta.cotacao, faturamento)
            return render(request,'processar_pagamento.html',{'cliente_email': proposta.cliente.email})
        return render(request, 'erro.html',{'raise_error':'Erro ao efetuar ao realizar faturamento.'})


class efetuar_pagamento(View):
    template_name ='efetuar_pagamento.html'

    def get_valores_parcelas(self,qtd_max_parcelas,valor):
        result=[('','Selecione uma parcela'),]
        for index in range(1, qtd_max_parcelas):
            result.append((index, '{0}x R$ {1}'.format(str(index),round(Decimal(valor/index),2))))
        return result

    def parcelas_instalacao(self,cotacao):
        return self.get_valores_parcelas(cotacao.parc_taxa_instalacao+1,cotacao.taxa_instalacao)

    def parcelas_seguro(self, cotacao):
        if cotacao.produto == "Rastreamento":
            return self.get_valores_parcelas(cotacao.parc_rastreamento+1,cotacao.rastreamento)
        elif cotacao.produto == "Rastreamento+Seguro":
            valor_seguro = round(Decimal(cotacao.valor_seguro) + Decimal(cotacao.iof) + Decimal(cotacao.rastreamento),2)
            return self.get_valores_parcelas(cotacao.parc_rastreamento+1,valor_seguro)

    def formatar_numero_cartao(self, numero_cartao):
        data_split = list(numero_cartao)
        return '**** **** **** {0}'.format(''.join(data_split[-4:]))

    def format_data_nascimento(self,data_nascimento):
        data_split = data_nascimento.split('/')
        dia, mes, ano = data_split[0],data_split[1],data_split[2]
        return '{0}-{1}-{2}'.format(ano,mes,dia)

    def get(self, request,*args, **kwargs):
        proposta = PreProposta.objects.filter(id = request.session.get('pre_proposta_id')).first()
        if not proposta:
            return HttpResponseRedirect('/')
        moip_api = MoipAPI()
        #Criar Cliente Moip
        moip_cliente = moip_api.criar_cliente(proposta.cliente)
        if not moip_api:
            return render(request, 'erro.html',{'raise_error':'Erro ao criar Cliente na plataforma de pagamento'})
        #Criar Pedido Moip - Taxa de Instalação
        moip_pedido = moip_api.criar_pedido(moip_cliente,proposta.cliente, proposta.cotacao.produto, str(proposta.cotacao.valor_total).replace('.',''))
        if not moip_pedido:
            return render(request, 'erro.html',{'raise_error':'Erro ao criar Pedido na plataforma de pagamento'})
        #Dados de Parcelamento
        initial_data = {'parcelas_instalacao':self.parcelas_instalacao(proposta.cotacao),
                        'parcelas_seguro':self.parcelas_seguro(proposta.cotacao),
                        'produto': proposta.cotacao.produto}
        request.session['moip_cliente']= moip_cliente
        request.session['moip_pedido']= moip_pedido
        return render(request, self.template_name, {'initial_data':initial_data})

    def post(self, request,*args, **kwargs):
        proposta = PreProposta.objects.filter(id = request.session.get('pre_proposta_id')).first()
        if not proposta:
            return HttpResponseRedirect('/')

        moip_api = MoipAPI()
        pagamento = PagamentoMoip.objects.create(cliente_id = proposta.cliente, veiculo_id = proposta.veiculo,
                                  descricao_produto = proposta.cotacao.produto, valor = proposta.cotacao.valor_total, proposta = proposta)

        pagamento_instalacao_moip = moip_api.criar_pagamento(proposta.cliente,request.session.get('moip_pedido'),request.POST['taxa_instalacao'],request.POST['hash'],
                                                             request.POST['titular_cartao'],self.format_data_nascimento(request.POST['data_nascimento']),request.POST['cpf'])

        if pagamento_instalacao_moip:
            #Se o pagamento for realizado com sucesso, registrar no banco de dados os dados de transação.
            pagamento_instalacao = ItemPagamentoMoip.objects.create(pagamento_id=pagamento, valor_total=proposta.cotacao.taxa_instalacao,
                                                     valor_parcela=(proposta.cotacao.taxa_instalacao / int(request.POST['taxa_instalacao'])),
                                                     qtd_parcelas = int(request.POST['taxa_instalacao']), tipo_pagamento = 1, #Cartão de Crédito
                                                     codigo_pagamento_moip = pagamento_instalacao_moip, codigo_cliente_moip=request.session.get('moip_cliente'),
                                                     nome_titular_cartao=request.POST['titular_cartao'], data_nascimento_titular=self.format_data_nascimento(request.POST['data_nascimento']),
                                                     cpf_titular=request.POST['cpf'],ultimos_digitos_cartao=self.formatar_numero_cartao(request.POST['numero_cartao']),
                                                     descricao_item="Instalação")

            #Criar Plano com o valor do seguro/rastreamento - recorrência
            print(pagamento_instalacao)
            plano_recorrencia = moip_api.criar_plano(proposta,int(request.POST['valor_seguro']))
            print(plano_recorrencia)
            if not plano_recorrencia:
                return render(request, 'erro.html',{'raise_error':'Erro ao criar plano de recorrência na plataforma de pagamento'})
            #Criar Plano com Assinante (Incluir cliente no Plano)
            assinatura_com_assinante = moip_api.criar_assinatura_com_assinante(proposta,plano_recorrencia)
            print(assinatura_com_assinante)
            if not assinatura_com_assinante:
                return render(request, 'erro.html',{'raise_error':'Erro ao incluir o cliente no plano de recorrência na plataforma de pagamento'})

            if pagamento_instalacao and assinatura_com_assinante:
                if assinatura_com_assinante.get('next_invoice_date'):
                    primeira_fatura = '{0}-{1}-{2}'.format(assinatura_com_assinante.get('next_invoice_date').get('year'),assinatura_com_assinante.get('next_invoice_date').get('month'),assinatura_com_assinante.get('next_invoice_date').get('day'))
                    ultima_fatura = '{0}-{1}-{2}'.format(assinatura_com_assinante.get('expiration_date').get('year'),assinatura_com_assinante.get('expiration_date').get('month'),assinatura_com_assinante.get('expiration_date').get('day'))
                else:
                    data_expiracao = '{0}-{1}-{2}'.format(assinatura_com_assinante.get('expiration_date').get('year'),assinatura_com_assinante.get('expiration_date').get('month'),assinatura_com_assinante.get('expiration_date').get('day'))
                    primeira_fatura=data_expiracao
                    ultima_fatura=data_expiracao
                #Criar os registros da transação - criação de plano de assinatura.
                pagamento_seguro_rastreamento = ItemPagamentoMoip.objects.create(pagamento_id=pagamento, valor_total=proposta.cotacao.valor_seguro_rastreamento,
                                                         valor_parcela=(proposta.cotacao.valor_seguro_rastreamento / int(request.POST['valor_seguro'])),
                                                         qtd_parcelas = int(request.POST['valor_seguro']), tipo_pagamento = 2, #Cartão de Crédito - Recorrência
                                                         codigo_plano = plano_recorrencia, codigo_cliente_moip=request.session.get('moip_cliente'),
                                                         nome_titular_cartao=request.POST['titular_cartao'], data_nascimento_titular=self.format_data_nascimento(request.POST['data_nascimento']),
                                                         cpf_titular=request.POST['cpf'],ultimos_digitos_cartao=self.formatar_numero_cartao(request.POST['numero_cartao']),
                                                         data_primeira_parcela=primeira_fatura, data_ultima_parcela=ultima_fatura,
                                                         codigo_assinatura_plano=assinatura_com_assinante.get('code'),
                                                         descricao_item=proposta.cotacao.produto)

                return render(request, 'confirmacao_pagamento.html', {'pagamento_instalacao_codigo': pagamento_instalacao.codigo_pagamento_moip,
                                                                  'valor_total_instalacao': round(pagamento_instalacao.valor_total,2),
                                                                  'qtd_parcelas_instalacao': pagamento_instalacao.qtd_parcelas,
                                                                  'valor_parcela_instalacao': round(pagamento_instalacao.valor_parcela,2),
                                                                  'pagamento_seguro_rastreamento': pagamento_seguro_rastreamento.codigo_assinatura_plano,
                                                                  'produto_seguro_rastreamento': pagamento_seguro_rastreamento.descricao_item,
                                                                  'valor_total_seguro': round(pagamento_seguro_rastreamento.valor_total,2),
                                                                  'valor_parcela_seguro': round(pagamento_seguro_rastreamento.valor_parcela,2),
                                                                  'qtd_parcelas_seguro': pagamento_seguro_rastreamento.qtd_parcelas,
                                                                  'primeira_parcela_seguro': pagamento_seguro_rastreamento.data_primeira_parcela
                                                                  })
            return render(request, 'erro.html',{'raise_error':'Erro ao incluir o cliente no plano de recorrência na plataforma de pagamento'})
                #confirmar com o moip a questão do valor da assinatura.
        return render(request, 'erro.html',{'raise_error':'Erro ao efetuar cobrança da taxa de instalação na plataforma de pagamento'})


def gerar_contrato(proposta, cliente, cod_pagamento):
    template_contrato = ''
    data={}
    pagamento_instalacao = ItemPagamentoMoip.objects.filter(pagamento_id=cod_pagamento,descricao_item__iexact='Instalação').first()
    plano_rastreamento_seguro = ItemPagamentoMoip.objects.filter(pagamento_id=cod_pagamento,descricao_item__icontains='Rastreamento').first()
    if plano_rastreamento_seguro:
        data_atual = date.today()
        aparelho_comodato = ServicosDoisMinutos.objects.filter(nome__iexact="Equipamento Comodato").first()
        endereco_cliente = Endereco.objects.filter(cliente__id=cliente.id).first()
        telefone_celular = Telefone.objects.filter(cliente__id=cliente.id, tipo_telefone = 2).first()
        telefone_fixo = Telefone.objects.filter(cliente__id=cliente.id, tipo_telefone = 1).first()
        telefone_comercial = Telefone.objects.filter(cliente__id=cliente.id, tipo_telefone = 3).first()
        if proposta.cotacao.produto == "Rastreamento":
            template_contrato = "template_ss.html"

            data = {
                "imagem_contrato": "{0}{1}".format(settings.BASE_DIR,"/vendas/templates/images/doisminutos_logo.png"),
                "nome": '{0}'.format(cliente.nome),
                "cpf": '{0}'.format(cliente.cpf),
                "rua": '{0}'.format(endereco_cliente.rua),
                "numero": '{0}'.format(endereco_cliente.numero),
                "cep": '{0}'.format(endereco_cliente.cep),
                "bairro": '{0}'.format(endereco_cliente.bairro),
                "cidade": '{0}'.format(endereco_cliente.cidade),
                "estado": '{0}'.format(get_sigla_codigo(endereco_cliente.estado)),
                "vlr_moni_mes": '{0}'.format(plano_rastreamento_seguro.valor_parcela),
                "vlr_instalacao": '{0}'.format(pagamento_instalacao.valor_total),
                "dia": '{0}'.format(data_atual.day),
                "mes": '{0}'.format(get_mes(data_atual.month)),

                "telefone_celular": '({0}) {1}'.format(telefone_celular.ddd_telefone, telefone_celular.telefone),
                "email": '{0}'.format(cliente.email),

                "dia_pagamento": '{0}'.format(str(plano_rastreamento_seguro.data_primeira_parcela).split('-')[2]),

                "vlr_equipamento_comodato": '{0}'.format(aparelho_comodato.valor),

                "marca": '{0}'.format(proposta.veiculo.marca),
                "modelo": '{0}'.format(proposta.veiculo.modelo),
                "cor": '{0}'.format(proposta.veiculo.cor),
                "ano_fabricacao": '{0}'.format(proposta.veiculo.ano),
                "placa": '{0}'.format(proposta.veiculo.placa),

            }

        if proposta.cotacao.produto == "Rastreamento+Seguro":
            template_contrato = "template_cs.html"
            data = {
                "imagem_contrato": "{0}{1}".format(settings.BASE_DIR,"/vendas/templates/images/doisminutos_logo.png"),
                "nome": '{0}'.format(cliente.nome),
                "cpf": '{0}'.format(cliente.cpf),
                "rua": '{0}'.format(endereco_cliente.rua),
                "numero": '{0}'.format(endereco_cliente.numero),
                "cep": '{0}'.format(endereco_cliente.cep),
                "bairro": '{0}'.format(endereco_cliente.bairro),
                "cidade": '{0}'.format(endereco_cliente.cidade),
                "estado": '{0}'.format(get_sigla_codigo(endereco_cliente.estado)),
                "vlr_moni_mes": '{0}'.format(plano_rastreamento_seguro.valor_parcela),
                "vlr_instalacao": '{0}'.format(pagamento_instalacao.valor_total),
                "dia": '{0}'.format(data_atual.day),
                "mes": '{0}'.format(get_mes(data_atual.month)),

                "nacionalidade": '{0}'.format(cliente.nacionalidade),
                "telefone_residencial": '({0}) {1}'.format(telefone_fixo.ddd_telefone, telefone_fixo.telefone),
                "telefone_comercial": '({0}) {1}'.format(telefone_comercial.ddd_telefone, telefone_comercial.telefone),
                "telefone_celular": '({0}) {1}'.format(telefone_celular.ddd_telefone, telefone_celular.telefone),
                "email": '{0}'.format(cliente.email),

                "marca": '{0}'.format(proposta.veiculo.marca),
                "modelo": '{0}'.format(proposta.veiculo.modelo),
                "cor": '{0}'.format(proposta.veiculo.cor),
                "ano_fabricacao": '{0}'.format(proposta.veiculo.ano),
                "placa": '{0}'.format(proposta.veiculo.placa),
                "cidade_veiculo": '{0}'.format(proposta.veiculo.cidade_veiculo),
                "estado_veiculo": '{0}'.format(get_sigla_codigo(endereco_cliente.estado)), #Modificar usando choice field
                "chassi": '{0}'.format(proposta.veiculo.chassi),
                "renavam": '{0}'.format(proposta.veiculo.renavam),

                "termo_inicial": '{0}/{1}/{2}'.format(data_atual.day, data_atual.month, data_atual.year), #Data da aprovação do pagamento
                "termo_final": '{0}'.format(get_termo_final(data_atual)),   #12 meses depois da data de aprovação do pagamento

                "vlr_total": '{0}'.format(plano_rastreamento_seguro.pagamento_id.valor), #Valor total.. rastreamento + seguro + instalção
                "vlr_equipamento_comodato": '{0}'.format(aparelho_comodato.valor), #Tem que ter um cadastro no banco assim como temos para taxa de instalção (valor inicial 350)
                "qtd_parcelas_moni": '{0}'.format(plano_rastreamento_seguro.qtd_parcelas), #Quantidade de parcelas que foi dividido o seguro/rastreamento
                "data_primeira_parcela": '{0}'.format(plano_rastreamento_seguro.data_primeira_parcela), #Data da primeira parcela do seguro/rastreamento
                "data_ultima_parcela": '{0}'.format(plano_rastreamento_seguro.data_ultima_parcela) #Data da última parcela do seguro/rastreamento
            }

        url_arquivo= gerador_pdf.run(template_contrato, data, cod_pagamento)
        if url_arquivo:
            return url_arquivo
    return False


#Funções que consomem dados de APIs
def consulta_sinesp(placa):
    try:
        consulta_sinesp_url = 'https://webmedia.org.br/teste/placa.php?placa='
        response = requests.get('{0}{1}'.format(consulta_sinesp_url,placa), verify=False)
        result = check_status(response.json())
        if result:
            return response.json()
        return result
    except:
        return False


def assinar_digitalmente(cliente, url_contrato):
    click_sign = ClickSign(cliente,url_contrato)
    result = click_sign.criar_documento()
    return result


def enviar_email(cliente_email, assunto, corpo_email, template, **kwargs):
    message_template = get_template(template).render({'corpo_email':corpo_email},**kwargs)
    email = EmailMessage(assunto, message_template, to=[cliente_email])
    email.content_subtype='html'
    email.send()
    return True


#Funções auxiliares - Parser de Dados
def formatar_valor_moip(valor):
    valor_ = str(valor).split('.')
    if valor_[1]!='00':
        return '{0}'.format(valor).replace('.','')
    elif valor_[1]=='0':
        return '{0}00'.format(valor).replace('.','')
    return '{0}0'.format(valor).replace('.','')


def get_sigla_codigo(codigo_uf):
    for estado in ESTADOS:
        if estado[0]==codigo_uf:
            return estado[1]


def get_mes(mes_atual):
    meses = [(1,'Janeiro'),(2,'Fevereiro'),(3,'Março'),(4,'Abril'),(5,'Maio'),(6,'Junho'),(7,'Julho'),(8,'Agosto'),(9,'Setembro'),(10,'Outubro'),(11,'Novembro'),(12,'Dezembro')]
    for mes in meses:
        if mes[0]==mes_atual:
            return mes[1]


def get_termo_final(termo_inicial):
    prazo = date.fromordinal(termo_inicial.toordinal()+364)
    return '{0}/{1}/{2}'.format(prazo.day, prazo.month, prazo.year)


def get_cliente(cpf):
    cliente = Cliente.objects.filter(cpf=cpf).all().first()
    if cliente:
        return cliente
    return Cliente(cpf=cpf)


def get_cliente_by_email(email):
    cliente = Cliente.objects.filter(email=email).all().first()
    if cliente:
        return cliente
    return Cliente(email=email)

def get_telefone(cliente_id, tipo_telefone):
    telefone_celular = Telefone.objects.filter(cliente__id=cliente_id.id, tipo_telefone=tipo_telefone).first()
    if telefone_celular:
        return telefone_celular
    return Telefone(cliente=cliente_id, tipo_telefone=tipo_telefone)


def get_endereco_cliente(cliente_id):
    endereco = Endereco.objects.filter(cliente__id=cliente_id.id).first()
    if endereco:
        return endereco
    return Endereco(cliente=cliente_id)


def formatar_campo(campo):
    return campo.replace('.','').replace('-','').replace('(', '').replace(')', '').replace(' ', '')


def consultar_cep(cep):
    return pycep_correios.consultar_cep(cep)


def check_status(result):
    if result:
        result_code = result.get('codigoRetorno')
        if int(result_code) != 0:
            print('Mensagem: {0}'.format(result.get('mensagemRetorno')))
            return False
        return True


def get_codigo_UF(UF):
    estados_siglas =[('Acre','AC'),('Alagoas','AL'),('Amapá','AP'),('Amazonas','AM'),('Bahia','BA'),
                    ('Ceará','CE'),('Distrito Federal','DF'),('Espírito Santo','ES'),('Goiás','GO'),
                    ('Maranhão','MA'),('Mato Grosso','MT'),('Mato Grosso do Sul','MS'),('Minas Gerais','MG'),
                    ('Pará','PA'),('Paraíba','PB'),('Paraná','PR'),('Pernambuco','PE'),('Piauí','PI'),('Rio de Janeiro','RJ'),
                    ('Rio Grande do Norte','RN'),('Rio Grande do Sul','RS'),('Rondônia','RO'),('Roraima','RR'),('Santa Catarina','SC'),
                    ('São Paulo','SP'),('Sergipe','SE'),('Tocantins','TO'),]

    for estado_sigla in estados_siglas:
        if estado_sigla[1]==UF:
            for estado in ESTADOS:
                if estado[1]==estado_sigla[0]:
                    return estado[0]
    return False


def atualiza_status_formulario(cotacao_id,status):
    cotacao = Cotacoes.objects.filter(id=cotacao_id).first()
    if status > int(cotacao.status_formulario):
        cotacao.status_formulario = str(status)
        cotacao.save()

def pagamento_sucesso(request):
    return render(request, 'confirmacao_pagamento.html')


def visualizar_contrato(request, param):
    try:
        return FileResponse(open('{0}contrato_{1}'.format(settings.DIRETORIO_CONTRATOS,param), 'rb'), content_type='application/pdf')
    except FileNotFoundError:
        raise Http404()

def processar_pagamento(request):
    return render(request, 'processar_pagamento.html')


#####Views para renderização de páginas do site####
def para_empresas(request):
    return render(request, 'para-empresas.html')

def para_voce(request):
    return render(request, 'para-voce.html')

def franquia2minutos(request):
    return render(request, 'franquia2minutos.html')

def produtos_empresa(request):
    return render(request, 'produtos-empresa.html')

def acessesistema(request):
    return render(request, 'acessesistema.html')

def index(request):
    return render(request, 'index.html')

TIPO_TELEFONE = [
    ('','Selecione o tipo de telefone'),
    ('1', 'Fixo'),
    ('2', 'Celular'),
    ('3', 'Comercial'),
]

TIPO_PROPRIETARIO = [
    ('','Selecione'),
    ('1', 'É proprietário'),
    ('2', 'Não é proprietário'),
]

TIPO_PAGAMENTO = [
    ('','Selecione'),
    (1, 'Cartão de Crédito - Rotativo'),
    (2, 'Cartão de Crédito - Recorrente'),
    (3, 'Boleto'),
]

TIPO_USO = [
    (1, 'Uso privado'),
    #(2, 'Uso comercial'),
]

SEXO = [
    ('','Selecione o sexo'),
    ('1', 'Masculino'),
    ('2', 'Feminino'),
]

TIPO_CONTAMOIP = [
    ('1', 'PRIMARY'),
    ('2', 'SECONDARY'),
]

FUEL_CHOICES = [
    ('','Selecione o tipo de combustível'),
    ('1', 'Gasolina'),
    ('2', 'Álcool'),
    ('3', 'Diesel'),
    ('4', 'Bicombustivel'),
    ('5', 'Gás'),
    ('6', 'Tricombustivel'),
    ('7', 'Tetrafuel'),
]

ESTADO_CIVIL = [
    ('','Selecione o estado civil'),
    ('1', 'Solteiro'),
    ('2', 'Casado'),
    ('3', 'Amasiado'),
    ('4', 'Divorciado'),
    ('5', 'Viuvo'),
    ('6', 'Separado'),
]

ESTADOS = [
    ('','Selecione o Estado'),
    ('59', 'Acre'),
    ('8', 'Alagoas'),
    ('61', 'Amapá'),
    ('60', 'Amazonas'),
    ('13', 'Bahia'),
    ('62', 'Ceará'),
    ('15', 'Distrito Federal'),
    ('21', 'Espírito Santo'),
    ('22', 'Goiás'),
    ('4', 'Maranhão'),
    ('24', 'Mato Grosso'),
    ('3', 'Mato Grosso do Sul'),
    ('17', 'Minas Gerais'),
    ('20', 'Pará'),
    ('18', 'Paraíba'),
    ('63', 'Paraná'),
    ('14', 'Pernambuco'),
    ('12', 'Piauí'),
    ('2', 'Rio de Janeiro'),
    ('64', 'Rio Grande do Norte'),
    ('23', 'Rio Grande do Sul'),
    ('6', 'Rondônia'),
    ('26', 'Roraima'),
    ('11', 'Santa Catarina'),
    ('1', 'São Paulo'),
    ('9', 'Sergipe'),
    ('5', 'Tocantins'),
]

FORMA_PAGAMENTO = [
    (1, 'CREDIT_CARD'),
    (2, 'BOLETO'),
    (3, 'ONLINE_BANK_DEBIT'),
    (4, 'WALLET'),
]

STATUS_PAGAMENTO = [
    (1,'WAITING_CHECKOUT'), #Implementação interna. Os demais status são definidos pela MOIP
    (2,'CREATED'),
    (3,'WAITING'),
    (4,'IN_ANALYSIS'),
    (5,'PRE_AUTHORIZED'),
    (6,'AUTHORIZED'),
    (7,'CANCELLED'),
    (8,'REFUNDED'),
    (9,'REVERSED'),
    (10,'SETTLED'),

]

STATUS_CONTRATO = [
    (1,'Criado'),
    (2,'Aguardando Assinatura'),
    (3,'Assinado'),
]

STATUS_FORMULARIO_COTACAO = [
    ('1','Informações Básicas'),
    ('2','Escolha do Veículo'),
    ('3','Escolha do Produto'),
    ('4','Preenchimento Formulario de Rastreamento'),
    ('5','Preenchimento Formulario de Rastreamento+Seguro')
]

STATUS_HABILITACAO = [
    ('','Selecione'),
    ('1', 'Habilitado'),
    ('2', 'Não Habilitado'),
]

RELACAO_PROPRIETARIO = [
    ('','Selecione'),
    ('1', 'O próprio'),
    ('2', 'Operação de leasing'),
    ('3', 'Veículo comprado recentemente e em transferência'),
    ('4', 'Veículo em nome de terceiro'),
]

TRANSFORMACAO_VEICULO = [
    ('','Selecione'),
    ('1', 'Não'),
    ('2', 'Sim, turbo e/ou rebaixado e/ou tunado'),
    ('3', 'Outras'),
]

GRAU_PARENTESCO = [
    ('','Selecione'),
    ('1', 'Cônjuge ou União Estável Comprovada'),
    ('2', 'Pais e Filhos ou Enteados'),
    ('3', 'Avós e Netos'),
    ('4', 'Irmãos'),
    ('5', 'Primos de primeiro grau'),
    ('6', 'Tios e Sobrinhos de primeiro grau'),
    ('7', 'PJ e Sócio / Adm no Contrato Social / Estatuto'),
    ('8', 'PJ e Diretor da Empresa'),
    ('9', 'Espólio do Proprietário Falecido'),
    ('10', 'Outro'),
]

FINS_UTILIZACAO = [
    ('','Selecione'),
    ('1','Particular'),
    ('2','Particular locado'),
    ('3','Motorista aplicativo (Uber, Pop, Cabify...)'),
    ('4','Representante comercial / vendedor'),
    ('5','Serviços técnicos'),
    ('6','Serviços de entrega'),
    ('7','Compartilhado (Car Sharing)'),
    ('8','Outros'),
]

FINS_UTILIZACAO_OK = [
    ('','Selecione'),
    ('1','Particular'),
    ('2','Particular locado'),
    ('3','Motorista aplicativo (Uber, Pop, Cabify...)'),
    ('4','Representante comercial / vendedor'),
    ('5','Serviços técnicos'),
    ('6','Serviços de entrega'),
    ('7','Compartilhado (Car Sharing)'),
    ('8','Outros'),
]

ADAPTACAO_PCD = [
    ('','Selecione'),
    ('1','Não'),
    ('2','Sim, PCD original de fábrica'),
    ('3','Sim, adaptado para PCD')
]

ADAPTACAO_GNV = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

BLINDADO = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

CRV_ASSINADO = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

TRANSFERENCIA_DETRAN = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

QTD_NUMERO_ROUBOS = [
    ('','Selecione'),
    ('1','Nenhum'),
    ('2','1'),
    ('3','2'),
    ('4','3'),
    ('5','4 ou mais'),
]

QUILOMETRAGEM_MENSAL = [
    ('','Selecione'),
    ('1','Até 500 km/mês'),
    ('2','Até 1000 km/mês'),
    ('3','Até 1250 km/mês'),
    ('4','Até 1500 km/mês'),
    ('5','Até 1700 km/mês'),
    ('6','Acima de 1750 km/mês'),
]

FINANCIADO = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

COR_VEICULO = [
    ('','Selecione'),
    ('1','Branco'),
    ('2','Preto'),
    ('3','Cinza'),
    ('4','Prata'),
    ('5','Azul'),
    ('6','Bege'),
    ('7','Vermelho'),
    ('8','Amarelo'),
    ('9','Laranja'),
    ('10','Marrom'),
    ('11','Verde'),
    ('12','Outra'),
]

CONDUTOR_VEICULO = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

CATEGORIA_VEICULO = [
    ('','Selecione'),
    ('0','Convencional'),
    ('1','Táxi'),
    ('2','Locadora'),
    ('3','Aplicativo'),
    ('4','PCD'),
    ('5','Blindado'),
    ('6','GNV'),
]

TIPO_CONDUTOR = [
    ('','Selecione'),
    ('1','Pessoa Física'),
    ('2','Pessoa Jurídica COM condutor designado'),
    ('3','Pessoa Jurídica SEM condutor designado'),
]

COBERTURA_25_ANOS = [
    ('','Selecione'),
    ('0','Não'),
    ('1','Sim'),
]

VEICULO_NOVO = [
    ('','Selecione'),
    ('0','Veiculo Usado'),
    ('1','Veiculo Novo'),
]

GARAGEM_CASA = [
    ('','Selecione'),
    ('1','Sim, externo privado e pago'),
    ('2','Sim, com portão manual'),
    ('3','Sim, com portão automático ou porteiro'),
    ('4','Não ou outro tipo de garagem'),
]

GARAGEM_TRABALHO = [
    ('','Selecione'),
    ('5','Sim, interno da empresa em local fechado'),
    ('6','Sim, externo a empresa, privado e pago'),
    ('7','Não ou outro tipo de garagem'),
    ('8','Não usa para locomoção ao trabalho'),
    ('9','Não trabalha'),
]

GARAGEM_ESTUDO = [
    ('','Selecione'),
    ('10','Diurno em garagem privada e fechada - paga'),
    ('11','Diurno sem garagem'),
    ('12','Não estuda'),
    ('13','Não utiliza o veículo para locomoção ao local de estudo'),
    ('14','Noturno em garagem privada e fechada - paga'),
    ('15','Noturno sem garagem'),
]

RENOVACAO = [
    ('','Selecione'),
    ('1','Sim'),
    ('2','Não'),
]

CLASSE_BONUS = [
    ('','Selecione'),
    ('0','0'),
    ('1','1'),
    ('2','2'),
    ('3','3'),
    ('4','4'),
    ('5','5'),
    ('6','6'),
    ('7','7'),
    ('8','8'),
    ('9','9'),
    ('10','10'),
]

SEGURADORAS = [
    ('','Selecione'),
    ('339141', '339141 - USEBENS SEGUROS S.A'),
    ('3466046', '3466046 - USEBENS SEGUROS S.A'),
    ('109647', '109647 - TOKIO MARINE BRASIL SEGURADORA S.A'),
    ('121234', '121234 - SUL AMERICA CIA NACIONAL DE SEGUROS'),
    ('3466007', '3466007 - AIG SEGUROS BRASIL S.A'),
    ('3466008', '3466008 - ALFA SEGURADORA S.A'),
    ('3466009', '3466009 - ALIANÇA DO BRASIL SEGUROS S.A'),
    ('3466010', '3466010 - ALLIANZ SEGUROS S.A'),
    ('3466014', '3466014 - BRASILVEÍCULOS COMPANHIA DE SEGUROS'),
    ('3466016', '3466016 - CAIXA SEGURADORA S.A'),
    ('3466017', '3466017 - CARDIF DO BRASIL SEGUROS E GARANTIAS S.A'),
    ('3466018', '3466018 - CESCEBRASIL SEGUROS DE GARANTIAS E CRÉDITO S.A'),
    ('3466019', '3466019 - CHUBB SEGUROS BRASIL S.A'),
    ('3466020', '3466020 - COMPANHIA DE SEGUROS ALIANÇA DA BAHIA'),
    ('3466021', '3466021 - COMPANHIA DE SEGUROS ALIANÇA DO BRASIL'),
    ('132029', '132029 - BRADESCO VIDA E PREVIDÊNCIA S.A'),
    ('352596', '352596 - SEGURADORA LÍDER DOS CONSÓRCIOS DO SEGURO DPVAT S.A'),
    ('91317', '91317 - BMG SEGURADORA S.A'),
    ('189589', '189589 - SUL AMÉRICA CIA NACIONAL DE SEGUROS'),
    ('3466022', '3466022 - COMPANHIA DE SEGUROS DO ESTADO DE SÃO PAULO (COSESP)'),
    ('3466025', '3466025 - GENERALI BRASIL SEGUROS S.A'),
    ('3466026', '3466026 - GENTE SEGURADORA S.A'),
    ('3466027', '3466027 - HDI GLOBAL SEGUROS S.A'),
    ('3466028', '3466028 - HDI SEGUROS S.A'),
    ('3466031', '3466031 - INVESTPREV SEGURADORA S.A'),
    ('3466035', '3466035 - LIBERTY SEGUROS S.A'),
    ('3466036', '3466036 - MAPFRE SEGUROS GERAIS S.A'),
    ('3466037', '3466037 - MITSUI SUMITOMO SEGUROS S.A'),
    ('3466040', '3466040 - SAFRA SEGUROS GERAIS S.A'),
    ('3466041', '3466041 - SANCOR SEGUROS DO BRASIL S.A'),
    ('3466042', '3466042 - SEGURADORA BRASILEIRA DE CRÉDITO À EXPORTAÇÃO S.A'),
    ('3466043', '3466043 - SEGUROS SURA S.A'),
    ('3466033', '3466033 - ITAU SEGUROS S.A'),
    ('3466034', '3466034 - J. MALUCELLI SEGURADORA S/A'),
    ('3466038', '3466038 - PORTO SEGURO CIA DE SEGUROS GERAIS'),
    ('3466039', '3466039 - QBE BRASIL SEGUROS S.A'),
    ('3466044', '3466044 - SOMPO SEGUROS S.A'),
    ('3466045', '3466045 - SUHAI SEGURADORA S.A'),
    ('3466049', '3466049 - TOKIO MARINE SEGURADORA S.A'),
    ('3466023', '3466023 - COMPANHIA DE SEGUROS PREVIDÊNCIA DO SUL (PREVISUL)'),
    ('3466024', '3466024 - ESSOR SEGUROS S.A'),
    ('3466029', '3466029 - INDIANA SEGUROS S.A'),
    ('3466032', '3466032 - ITAU SEGUROS DE AUTO E RESIDÊNCIA'),
]

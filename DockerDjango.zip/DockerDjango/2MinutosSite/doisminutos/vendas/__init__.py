default_app_config = 'vendas.apps.VendasConfig'

from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import IndicacaoCorretor, Corretor, Contrato, Cliente,ConfiguracoesAPIMoip, ConfiguracoesAPIClickSign,PreProposta
from .views import enviar_email

@receiver(post_save, sender=IndicacaoCorretor, dispatch_uid="update_indicacao_corretor")
def update_indicacao_corretor(sender, instance, **kwargs):
    if int(instance.status) == 1:
        corretor = Corretor(nome=instance.nome, email=instance.email, ddd_telefone=instance.ddd_telefone, telefone=instance.telefone, cnpj=instance.cnpj)
        corretor.save()
        propostas = PreProposta.objects.all().filter(indicacao_corretor=instance).update(indicacao_corretor=None,corretor=corretor)
        instance.delete()


@receiver(post_save, sender=Contrato, dispatch_uid="update_contrato")
def update_contrato(sender, instance, **kwargs):
    if int(instance.status_assinatura) == 1:
        cliente = Cliente.objects.filter(id=instance.cliente_id.id).first()
        params = ConfiguracoesAPIMoip.objects.all().first()
        enviar_email(cliente.email, params.assunto_email, params.corpo_email, 'email_confirmacao_pagamento.html')
        print('email confirmacão pagamento enviado com sucesso!')

    if int(instance.status_assinatura) == 3:
        cliente = Cliente.objects.filter(id=instance.cliente_id.id).first()
        params = ConfiguracoesAPIClickSign.objects.all().first()
        enviar_email(cliente.email, params.assunto_email, params.corpo_email, 'email_apos_assinatura_contrato.html')
        print('email confirmação assinatura do contrato enviado com sucesso!')

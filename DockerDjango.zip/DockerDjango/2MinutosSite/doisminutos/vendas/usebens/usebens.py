import json
import requests
from django.conf import settings
from ..models import ConfiguracoesAPIUseBens, Cliente, Endereco, Telefone, ProprietarioVeiculo, CondutorVeiculo, ServicosDoisMinutos, RenovacaoSeguro
import base64

def consulta_usebens_veiculos(veiculo):
    lista_veiculos=[]

    url = '{0}/vehicles?q={1}'.format(settings.BASE_URL, veiculo)
    print("     Parâmetros de Consulta UseBens - Veiculos: {0} | URL: {1}".format(veiculo,url))
    response = requests.get(url, headers={'access_token': get_authorization().token},  verify=False)

    response_json = json.loads(response.text)
    # print(response_json)
    if 'error' in response_json:
        print("  acess_token invalido. gerando novo...")
        gerar_token()

    veiculo_response_json = response_json.get('items')
    print('UseBens consulta_usebens_veiculos',response.status_code)
    return veiculo_response_json

def get_authorization():
    return ConfiguracoesAPIUseBens.objects.all().first()

def verifica_marca_modelo_usebens(marca_modelo_usebens):
    result = consulta_usebens_veiculos(marca_modelo_usebens)
    parametro=''
    if result:
        parametro = marca_modelo_usebens.replace('+', ' ')
    else:
        parametro = marca_modelo_usebens.split('+')[0]
    return parametro

def gerar_token():
    autorization = get_authorization()
    encoded = base64.b64encode(('{0}:{1}'.format(autorization.key_api,autorization.secret_api)).encode())

    response = requests.post('{0}'.format(settings.BASE_URL), headers={'Authorization': 'Basic {0}'.format(encoded.decode("utf-8"))},  verify=False)
    response_json = json.loads(response.text)

    autorization.token = response_json['result']['access_token']
    autorization.save()

    return autorization

def parser_sinesp_usebens(modelo_veiculo):
    modelo_veiculo_spllited = modelo_veiculo.split(' ')
    if modelo_veiculo_spllited[0].startswith('I/'):
        modelo_veiculo_spllited[0] = modelo_veiculo_spllited[0].split('/')[1]
        marca_modelo_veiculo = modelo_veiculo_spllited[:2]
        return "+".join(marca_modelo_veiculo)

    modelo_veiculo_replaced = modelo_veiculo_spllited[:1]
    modelo_veiculo_replaced = '+'.join(modelo_veiculo_replaced)
    modelo_veiculo_replaced = modelo_veiculo_replaced.replace('/','+')
    return modelo_veiculo_replaced

def efetuar_cotacao(cliente,veiculo,cotacao):
    print("     Parâmetros Cotação UseBens: Cliente: {0} | Veiculos: {1}".
                format(cliente.cpf,veiculo))
    endereco_cliente = Endereco.objects.filter(cliente__id=cliente.id).first()
    proprietario = ProprietarioVeiculo.objects.filter(cotacao = cotacao).first()
    condutor = CondutorVeiculo.objects.filter(cotacao = cotacao).first()
    renovacao_seguro = RenovacaoSeguro.objects.filter(cotacao = cotacao).first()

    result=[]

    client={
        "type": 1, #Pessoa Fisica
        "tax_document": "{0}".format(cliente.cpf),
        "zip_code": "{0}".format((endereco_cliente.cep).replace('-','')),
        "relation_with_owner": "{0}".format(veiculo.relacao_proprietario),
    }

    if veiculo.relacao_proprietario in ('2','3','4'):
        client.update(family_relation_with_owner =  "{0}".format(proprietario.grau_parentesco))

    vehicle = {
        "fipe": "{0}".format(veiculo.fipe),
        "year_model": "{0}".format(veiculo.ano_modelo),
        "is_new":  "{0}".format(veiculo.veiculo_novo),
        "fuel":  "{0}".format(veiculo.combustivel),
        "fare_category": "{0}".format(veiculo.categoria_tarifaria),
        "make": "{0}".format(veiculo.marca),
        "model": "{0}".format(veiculo.modelo),
        "year_manufacture": "{0}".format(veiculo.ano),
        "category": "{0}".format(veiculo.categoria),
        "contingency_install": 0,
        "transformation_id":  "{0}".format(veiculo.transformacao_veiculo),
        "use":  "{0}".format(veiculo.fins_utilizacao),
        "pcd":  "{0}".format(veiculo.adaptacao_pcd),
        "gnv":  "{0}".format(veiculo.adaptacao_gnv),
        "armoured": "{0}".format(veiculo.blindado),
        "detran_transfer":  "{0}".format(veiculo.transferencia_detran),
        "number_thefts":  "{0}".format(veiculo.numero_roubos)
    }

    if veiculo.relacao_proprietario == '3':
        vehicle.update(date_purchase = "{0}".format(veiculo.data_compra))
        vehicle.update(crv_signed = "{0}".format(veiculo.crv_assinado))

    driver = {
        "is_client": "{0}".format(condutor.condutor_principal),
        "type": "{0}".format(condutor.tipo)
    }

    if condutor.tipo in ('1','2'):
        driver.update(minor_25_yo = "{0}".format(condutor.cobertura_25_anos))
        driver.update(garage_home = "{0}".format(condutor.garagem_casa))
        driver.update(garage_work = "{0}".format(condutor.garagem_trabalho))
        driver.update(garage_study = "{0}".format(condutor.garagem_estudo))
        driver.update(monthly_km = "{0}".format(condutor.quilometragem_mensal))

        if condutor.condutor_principal == '0':
            driver.update(gender = "{0}".format(condutor.sexo))
            driver.update(birthdate = "{0}".format(condutor.data_nascimento))
            driver.update(marital_status = "{0}".format(condutor.estado_civil))
        else:
            driver.update(gender = "{0}".format(cliente.sexo))
            driver.update(birthdate = "{0}".format(cliente.data_nascimento))
            driver.update(marital_status = "{0}".format(cliente.estado_civil))


    insurance = {
        "cover_ids": "[753]",
        "cover_lmi": "[0.00]",
        "validity": 12
    }

    if renovacao_seguro:

        if renovacao_seguro.cod_seguradora_atual in ('339141','3466046' ):

            insurance.update(renewal = "{0}".format(1)) #Seguro renovado com a próŕia UseBens
        else:
            print('tem renovacao OUTRA!!!!!')
            insurance.update(renewal = "{0}".format(2)) #Seguro renovado - outra seguradora
            insurance.update(current_bonus_class = "{0}".format(renovacao_seguro.classe_bonus))
            insurance.update(current_ci = "{0}".format(renovacao_seguro.numero_ci))
            insurance.update(current_policy_number = "{0}".format(renovacao_seguro.apolice_atual))
            insurance.update(current_policy_date_exp = "{0}".format(renovacao_seguro.exp_apolice_atual))
            insurance.update(current_insurer = "{0}".format(renovacao_seguro.cod_seguradora_atual))
    else:
        insurance.update(renewal = "{0}".format(3)) #Contratação de novo seguro

    consulta_cotação = {
        'product_id': 109,
        'client':client,
        'vehicle':vehicle,
        'driver':driver,
        'insurance':insurance
    }
    print(consulta_cotação)
    response = requests.post('{0}/quote'.format(settings.BASE_URL), json = consulta_cotação, headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print(response_json)
    print('UseBens efetuar_cotacao',response.status_code)
    return response_json


def consulta_profissao():
    response = requests.get('{0}/occupation'.format(settings.BASE_URL), headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    #return HttpResponse(json.dumps(response_json, indent=4, sort_keys=True), content_type="application/json")
    print('UseBens consulta_profissao',response.status_code)
    return response_json

def consulta_ramo_atividade(request):
    response = requests.get('{0}/business_type'.format(settings.BASE_URL), headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    return HttpResponse(json.dumps(response_json, indent=4, sort_keys=True), content_type="application/json")

def pre_proposta_usebens(pre_proposta, cliente, veiculo, condutor_veiculo, proprietario):
    endereco_cliente = Endereco.objects.filter(cliente__id=cliente.id).first()
    telefone_celular = Telefone.objects.filter(cliente__id=cliente.id).first()
    telefone_fixo = Telefone.objects.filter(cliente__id=cliente.id).first()
    renovacao_seguro = RenovacaoSeguro.objects.filter(cotacao = pre_proposta.cotacao).first()

    quote={
        "id": pre_proposta.cotacao.cotacao_usebens_id,
        "i4pro_code": pre_proposta.cotacao.cotacao_i4Pro_usebens_id
    }

    if renovacao_seguro:
        insurance={
            "renewal": '{0}'.format(renovacao_seguro.renovacao)
            }
    else:
        insurance={
            "renewal": '{0}'.format(3)
            }

    client={
        "type": cliente.tipo_cliente,
        "tax_document": cliente.cpf,
        "name":cliente.nome,
        "birthdate": '{0}'.format(cliente.data_nascimento),
        "gender": cliente.sexo,
        "marital_status": cliente.estado_civil,
        "email": cliente.email,
        "occupation": cliente.ocupacao_id
    }

    address={
        "street": endereco_cliente.rua,
        "number": '{0}'.format(endereco_cliente.numero),
        "complement": endereco_cliente.complemento,
        "district": endereco_cliente.bairro,
        "city": endereco_cliente.cidade,
        "state": endereco_cliente.estado,
        "zip_code": (endereco_cliente.cep).replace('-',''),
    }

    phone =[{
        "type": telefone_celular.tipo_telefone,
        "area_code":  telefone_celular.ddd_telefone,
        "number":  int(telefone_celular.telefone)
    },{
        "type":  telefone_fixo.tipo_telefone,
        "area_code":  telefone_fixo.ddd_telefone,
        "number": int(telefone_fixo.telefone)
    }]

    vehicle={
        "license_plate": veiculo.placa,
        "vin": veiculo.chassi,
        "owner": "{0}".format(1 if veiculo.relacao_proprietario == '1' else 1),
        "use": "{0}".format(1 if veiculo.fins_utilizacao in ('1','2') else 2),
        "renavam": veiculo.renavam,
        "color": veiculo.cor,
        "mileage": condutor_veiculo.quilometragem_mensal,
        "financed": veiculo.financiado
    }

    pre_proposta_data = {
        'quote': quote,
        'client':client,
        'address':address,
        'phone':phone,
        'vehicle':vehicle,
        'insurance': insurance
    }

    owner = {}
    driver = {}
    if veiculo.relacao_proprietario in ('2','3','4'):
        proprietario = ProprietarioVeiculo.objects.filter(id=proprietario.id).first()
        owner = {
            "name": proprietario.nome,
            "birthdate": '{0}'.format(proprietario.data_nascimento),
            "tax_document": proprietario.cpf,
            "gender": proprietario.sexo,
            "family_relation": proprietario.grau_parentesco
        }

        pre_proposta_data.update(owner = owner)

    if condutor_veiculo.condutor_principal == '0':
        driver = {
            "name": condutor_veiculo.nome,
            "tax_document": condutor_veiculo.cpf
        }

        pre_proposta_data.update(driver = driver)


    response = requests.post('{0}/pre-proposal'.format(settings.BASE_URL), json = pre_proposta_data, headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print('UseBens pre_proposta_usebens',response_json)
    print(response)
    return response.json()

def consultar_parcelamento(cotacao):
    response = requests.get('{0}/quote/{1}/cost/resume'.format(settings.BASE_URL, cotacao.cotacao_usebens_id), headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print('Consultar Parcelamento Usebens',response_json)

    return response.json()


def criar_faturamento(cotacao):
    quote = {
        "id": '{0}'.format(cotacao.cotacao_usebens_id)
    }

    service = {
        "installation": {
            "amount": '{0}'.format(cotacao.taxa_instalacao),
            "installments": '{0}'.format(cotacao.parc_taxa_instalacao)
        },
        "monitoring": {
            "amount": '{0}'.format(cotacao.rastreamento),
            "installments": '{0}'.format(cotacao.parc_rastreamento)},
            "discount": {
                "amount": 0,
                "installments": 0
                }
    }

    faturamento_data = {
        'quote': quote,
        'service': service
    }
    print('UseBens faturamento data',faturamento_data)
    response = requests.post('{0}/invoice'.format(settings.BASE_URL), json = faturamento_data, headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print('UseBens faturamento',response_json)

    return response.json()


def formalizar_proposta(codigo_proposta_usebens):
    pre_proposal = {
        'code': codigo_proposta_usebens
    }
    print('->proposta',pre_proposal)
    response = requests.post('{0}/proposal'.format(settings.BASE_URL), json = {'pre_proposal': pre_proposal}, headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print('UseBens formalizar_proposta',response.status_code)
    return response_json


def notificacao_pagamento(cotacao, faturamento):
    client = {
        'email': cotacao.cliente.email
    }
    response = requests.post('{0}/payment/{1}/notify'.format(settings.BASE_URL, faturamento.usebens_invoice_id), json = {'client': client}, headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print('UseBens notificacao_pagamento',response.status_code)
    temp_url=('{0}/payment/{1}/notify'.format(settings.BASE_URL, faturamento.usebens_invoice_id))
    print("URL PAGAMENTO", temp_url)
    return response_json


def consultar_pagamento(faturamento):
    response = requests.get('{0}/payment/{1}/1'.format(settings.BASE_URL, faturamento), headers={'access_token': get_authorization().token},  verify=False)
    response_json = json.loads(response.text)
    print('UseBens consultar_pagamento',response.status_code)
    return response_json

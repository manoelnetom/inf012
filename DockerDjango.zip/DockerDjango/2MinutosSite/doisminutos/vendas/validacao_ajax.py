from django.http import JsonResponse
import datetime
import pycep_correios

def validar_cpf(request):
    cpf = request.GET['cpf']

    if not cpf:
        return JsonResponse({'valid':'false','message': 'CPF inválido!'})

    cpfs_conhecidos = ['00000000000','11111111111','22222222222','33333333333','44444444444',
                       '55555555555','66666666666','77777777777','88888888888','99999999999']

    if cpf in cpfs_conhecidos:
        return JsonResponse({'valid':'false','message': 'O CPF informado é inválido!'})

    if len(cpf) == 11 and cpf not in cpfs_conhecidos:
        #Cria variaveis para validacao
        cpf_list = list(cpf)
        elementos = list(range(10,1,-1))
        validar = 0
        index = 10
        #Gera o numero para validar o primeiro digito verificador
        for num1 in range(0,9):
        	validar += int(cpf_list[num1]) * elementos[num1]
        	index -= 1

        #Gera o primeiro digito verificador
        resto = (float(validar) * 10) % 11
        if resto == 10.0:
            resto = 0
        #Valida primeiro digito verificador
        digitos_verificadores = cpf_list[9:]

        primeiro_digito_valid = False
        primeiro_digito = int(digitos_verificadores[0])

        if (int(resto) == primeiro_digito):
        	primeiro_digito_valid = True
        #Zera variaveis para validacao do segundo digito verificador
        elementos = list(range(11,1,-1))
        validar = 0
        index = 11
        resto = 0
        #Gera o numero para validar o segundo digito verificador
        for num2 in range(0, 10):
        	validar += int(cpf_list[num2]) * elementos[num2]
        	index -= 1
        #Gera o segundo digito verificador
        resto = (float(validar) * 10) % 11
        if resto == 10.0:
            resto = 0
        #Valida o segundo digito verificador e imprime o CPF final
        segundo_digito_valid = False
        segundo_digito = int(digitos_verificadores[1])
        if (int(resto) == segundo_digito):
            segundo_digito_valid=True

        if primeiro_digito_valid and segundo_digito_valid:
            return JsonResponse({'valid':'true'}, status=200)
        else:
            return JsonResponse({'valid':'false','message': 'O CPF informado é inválido!'})
    else:
        return JsonResponse({'valid':'false','message': ' '})


def validar_cep(request):
    cep = request.GET['cep']

    if not cep:
        return JsonResponse({'valid':'false','message': 'CEP inválido!'})

    cep_correios = {}
    if len(cep) == 8:
        try:
            cep_correios = pycep_correios.consultar_cep(cep)
            return JsonResponse({'valid':'true'}, status=200)
        except Exception:
            return JsonResponse({'valid':'false','message': 'O CEP informado é inválido!'})
    return JsonResponse({'valid':'false','message': ' '})


def validar_data_nascimento(request):
    data_nascimento = request.GET['data_nascimento']

    if not data_nascimento:
        return JsonResponse({'valid':'false','message': 'A data de nascimento informada é inválida!'})

    ano_atual = datetime.datetime.now().year
    if len(data_nascimento) == 8:
        data_split = list(data_nascimento)
        dia, mes, ano = int(''.join(data_split[:2])), int(''.join(data_split[2:-4])), int(''.join(data_split[4:]))

        if ano >= ano_atual:
            return JsonResponse({'valid':'false','message': 'A data de nascimento informada é inválida!'})
        #PENDENTE: DEFINIÇÃO DE IDADE MINIMA E MÁXIMA

        try:
            datetime.datetime(ano, mes, dia)
            return JsonResponse({'valid':'true'}, status=200)
        except Exception:
            return JsonResponse({'valid':'false','message': 'A data de nascimento informada é inválida!'})
    return JsonResponse({'valid':'false','message': ' '})

def validar_data_compra(request):
    data_compra = request.GET['data_compra']

    if not data_compra:
        return JsonResponse({'valid':'false','message': 'A data de compra informada é inválida!'})

    ano_atual = datetime.datetime.now().year
    if len(data_compra) == 8:
        data_split = list(data_compra)
        dia, mes, ano = int(''.join(data_split[:2])), int(''.join(data_split[2:-4])), int(''.join(data_split[4:]))

        if ano >= ano_atual:
            return JsonResponse({'valid':'false','message': 'A data de compra informada é inválida!'})
        #PENDENTE: DEFINIÇÃO DE IDADE MINIMA E MÁXIMA

        try:
            datetime.datetime(ano, mes, dia)
            return JsonResponse({'valid':'true'}, status=200)
        except Exception:
            return JsonResponse({'valid':'false','message': 'A data de compra informada é inválida!'})
    return JsonResponse({'valid':'false','message': ' '})

def validar_data_apolice(request):
    #Validar se o prazo de expiração poderá ser no futuro ou a quantidade máxima de dias após expiração
    exp_apolice_atual = request.GET['exp_apolice_atual']

    if not exp_apolice_atual:
        return JsonResponse({'valid':'false','message': 'A data de expiração informada é inválida!'})

    ano_atual = datetime.datetime.now().year
    if len(exp_apolice_atual) == 8:
        data_split = list(exp_apolice_atual)
        dia, mes, ano = int(''.join(data_split[:2])), int(''.join(data_split[2:-4])), int(''.join(data_split[4:]))

        if ano >= ano_atual:
            return JsonResponse({'valid':'false','message': 'A data de expiração informada é inválida!'})
        #PENDENTE: DEFINIÇÃO DE IDADE MINIMA E MÁXIMA

        try:
            datetime.datetime(ano, mes, dia)
            return JsonResponse({'valid':'true'}, status=200)
        except Exception:
            return JsonResponse({'valid':'false','message': 'A data de expiração informada é inválida!'})
    return JsonResponse({'valid':'false','message': ' '})

def validar_data_validade_cartao(request):
    data_validade = request.GET['data_validade']

    if not data_validade:
        return JsonResponse({'valid':'false','message': 'A data de validade informada é inválida!'})

    ano_atual = datetime.datetime.now().year
    mes_atual = datetime.datetime.now().month

    if len(data_validade) == 6:
        data_split = list(data_validade)
        mes, ano = ''.join(data_split[:2]), int(''.join(data_split[2:]))

        meses_ano = ['01','02','03','04','05','06','07','08','09','10','11','12']
        if mes in meses_ano:
            if (ano == int(ano_atual)) and int(mes) >= int(mes_atual):
                return JsonResponse({'valid':'true'}, status=200)

            if (ano > int(ano_atual)):
                return JsonResponse({'valid':'true'}, status=200)
    return JsonResponse({'valid':'false','message': ' '})
